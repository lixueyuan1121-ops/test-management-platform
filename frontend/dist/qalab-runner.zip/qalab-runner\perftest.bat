@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"
title 纳米 Work 性能测试工具

:menu
cls
echo ============================================
echo    纳米 Work 性能测试工具  nami-perfdog
echo ============================================
echo   请选择测试场景：
echo.
echo    [1] 对话        发一条消息，全程 CPU/内存/FPS
echo    [2] 切换对话     切会话，测卡顿
echo    [3] 冷启动       从没开到打开，测启动快慢 [需先完全退出应用]
echo    [4] 热启动       后台切回来，测激活快慢
echo    [5] 杀进程       关闭应用，测关得干不干净
echo    [6] 自定义场景    自己起场景名
echo    [7] 竞品测试     指定别的 app 进程名 [只采系统级]
echo    [8] 长时监控     长时间挂机，抓缓慢泄漏/偶发卡顿 [到点或 Ctrl-C 停]
echo    [9] 首次安装     全新安装耗时+安装期资源 [手动框起止]
echo.
echo    [R] 生成 / 刷新对比报告
echo    [H] 查看使用帮助
echo    [Q] 退出
echo --------------------------------------------
set "choice="
set /p "choice=  请输入序号后回车: "

if /i "%choice%"=="1" set "SCENARIO=对话" & goto ask_variant
if /i "%choice%"=="2" set "SCENARIO=切换对话" & goto ask_variant
if /i "%choice%"=="3" set "SCENARIO=冷启动" & goto cold_note
if /i "%choice%"=="4" set "SCENARIO=热启动" & goto ask_variant
if /i "%choice%"=="5" set "SCENARIO=杀进程" & goto ask_variant
if /i "%choice%"=="6" goto custom
if /i "%choice%"=="7" goto competitor
if /i "%choice%"=="8" goto monitor
if /i "%choice%"=="9" goto install
if /i "%choice%"=="R" goto report
if /i "%choice%"=="H" goto help
if /i "%choice%"=="Q" goto end
echo.
echo   无效输入，请重新选择。
timeout /t 2 >nul
goto menu

:custom
echo.
set "SCENARIO="
set /p "SCENARIO=  输入自定义场景名 [如 长文档生成]: "
if "%SCENARIO%"=="" echo   场景名不能为空 & timeout /t 2 >nul & goto menu
goto ask_variant

:competitor
echo.
echo   竞品测试：采集别的应用，只采系统级 CPU/GPU/内存/耗时，无 FPS/任务指标
set "PROCNAME="
set /p "PROCNAME=  输入竞品进程名 [如 Doubao.exe]: "
if "%PROCNAME%"=="" echo   进程名不能为空 & timeout /t 2 >nul & goto menu
set "SCENARIO="
set /p "SCENARIO=  输入场景名 [如 对话，直接回车默认 对话]: "
if "%SCENARIO%"=="" set "SCENARIO=对话"
set "VARIANT="
set /p "VARIANT=  输入对象标签 [如 竞品豆包]: "
if "%VARIANT%"=="" set "VARIANT=竞品"
echo.
echo   即将采集： 场景=%SCENARIO%  对象=%VARIANT%  进程=%PROCNAME%
echo   按提示操作：先看基线，再回车开始，完成后再回车结束
echo.
node nami-perfdog.mjs run --scenario "%SCENARIO%" --variant "%VARIANT%" --proc "%PROCNAME%"
goto after_run

:monitor
echo.
echo   [长时监控] 长时间挂机监控 CPU/内存/FPS，抓缓慢内存泄漏与偶发卡顿。
echo   可设时长到点自停，或采集途中随时按 Ctrl-C 优雅结束并出报告。
echo.
set "DUR="
set /p "DUR=  输入监控时长 [如 12h / 30m / 90s，直接回车=手动 Ctrl-C 停]: "
set "VARIANT="
set /p "VARIANT=  输入被测对象标签 [如 2.4.0，直接回车默认 default]: "
if "%VARIANT%"=="" set "VARIANT=default"
echo.
if "%DUR%"=="" (
  echo   即将开始长监控： 对象=%VARIANT%  时长=手动 Ctrl-C 停
  node nami-perfdog.mjs run --scenario 长监控 --variant "%VARIANT%"
) else (
  echo   即将开始长监控： 对象=%VARIANT%  时长=%DUR%
  node nami-perfdog.mjs run --scenario 长监控 --variant "%VARIANT%" --duration "%DUR%"
)
goto after_run

:install
echo.
echo   [首次安装] 测全新安装耗时与安装期资源占用。
echo   流程：先采基线 → 回车后去双击安装包开始装 → 装完(看到"完成/Finish")再回车结束。
echo.
set "PROCNAME="
set /p "PROCNAME=  可选：安装程序进程名 [如 NamiworkSetup.exe，直接回车=只测耗时]: "
set "VARIANT="
set /p "VARIANT=  输入被测对象标签 [如 2.4.0，直接回车默认 default]: "
if "%VARIANT%"=="" set "VARIANT=default"
echo.
if "%PROCNAME%"=="" (
  echo   即将开始首次安装采集： 对象=%VARIANT%
  node nami-perfdog.mjs run --scenario 首次安装 --variant "%VARIANT%"
) else (
  echo   即将开始首次安装采集： 对象=%VARIANT%  安装器=%PROCNAME%
  node nami-perfdog.mjs run --scenario 首次安装 --variant "%VARIANT%" --proc "%PROCNAME%"
)
goto after_run

:cold_note
echo.
echo   [冷启动测试须知]
echo   1. 请先完全退出纳米 Work，含右下角托盘图标右键退出。
echo   2. 待会按回车后工具开始计时，你再去启动应用。
echo   3. 若要采 FPS 和启动各阶段，启动时请带调试端口，见帮助 H。
echo.
pause
goto ask_variant

:ask_variant
echo.
set "VARIANT="
set /p "VARIANT=  输入被测对象标签 [如 2.3.1197 或 竞品名，直接回车默认 default]: "
if "%VARIANT%"=="" set "VARIANT=default"
echo.
echo   即将采集： 场景=%SCENARIO%  对象=%VARIANT%
echo   按屏幕提示操作：先采基线别动，再回车开始，完成后再回车结束
echo.
node nami-perfdog.mjs run --scenario "%SCENARIO%" --variant "%VARIANT%"
goto after_run

:after_run
echo.
echo --------------------------------------------
echo   本次采集结束。可继续测下一个场景，或按 R 出报告。
echo.
pause
goto menu

:report
echo.
echo   正在生成对比报告，含全部已采集数据 ...
node nami-perfdog.mjs report
echo.
echo   报告已生成，见上方路径。浏览器应已自动打开，未打开则手动双击该 html。
echo.
pause
goto menu

:help
cls
echo ============================================
echo    使用帮助
echo ============================================
echo.
echo   [基本流程]
echo   1.选场景  2.填对象标签  3.按提示操作  4.回菜单继续或按 R 出报告
echo.
echo   [对象标签是什么]
echo   给这次被测对象起个名，如版本号 2.3.1197、2.4.0，或 竞品豆包。
echo   同一个场景、不同标签各测一次，报告会自动横向对比。
echo.
echo   [要采 FPS 或冷启动各阶段，需带调试端口启动纳米]
echo   先完全退出纳米，再在 PowerShell 运行下面这行：
echo     ^&  "D:\Program Files\Namiwork\Namiwork.exe"  --remote-debugging-port=9222
echo   不带也能测，只是没有 FPS 和启动分段耗时。
echo.
echo   [报告在哪]
echo   sessions 文件夹里的 perfdog-report-*.html，按 R 会生成最新的。
echo.
pause
goto menu

:end
echo.
echo   已退出。采集数据保存在 sessions 文件夹。
timeout /t 2 >nul
endlocal
