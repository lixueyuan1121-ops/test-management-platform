#!/usr/bin/env node
/**
 * perf-agent —— 平台性能任务执行机代理（类比 tools/qalab-runner/runner.mjs）。
 * 纯 Node（v18+ 内置 fetch），零依赖。
 *
 * 用法：
 *   node perf-agent.mjs              轮询平台队列，自动执行可无人值守的场景（长监控带 --duration）
 *   node perf-agent.mjs poll-once    只轮询一轮就退出（便于 Windows 计划任务定时调度/联调）
 *   node perf-agent.mjs upload [目录|--all]
 *                                    把本地已采集的 session 直传平台（冷启动/对话等交互场景用）
 *                                    省略目录=传 sessions 下所有"未打过 .uploaded 标记"的；
 *                                    --all=不管标记全传；给具体目录=只传那一个。
 *
 * 配置（同目录 .env 或环境变量）：BASE_URL / RUNNER_TOKEN / RUNNER_ID / PERFDOG_DIR / POLL_MS
 *
 * 设计要点：
 * - dispatch 轨只自动跑「长监控 + --duration」（perfdog 唯一能到点自停、无需人工回车的场景）；
 *   认领到交互场景（冷启动/对话/热启动/杀进程/首次安装）时回传 failed 并提示改走 upload，
 *   绝不假装成功——诚实反映 perfdog 的人工介入约束。
 * - 回传前按 metric 抽稀 samples（每指标≤2000 点），控制体积。
 * - runner 鉴权用 RUNNER_TOKEN（共享）或"我的设备"专属 token，与用户 JWT 分离。
 */
import { spawn } from 'node:child_process';
import { readFileSync, readdirSync, statSync, existsSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dir = dirname(fileURLToPath(import.meta.url));

// 极简 .env 载入（不覆盖已存在的环境变量）
try {
  const envPath = join(__dir, '.env');
  if (existsSync(envPath)) {
    for (const line of readFileSync(envPath, 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
      if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  }
} catch { /* 无 .env 用默认/环境变量 */ }

// ---- 配置 ----
const BASE_URL = (process.env.BASE_URL || 'http://localhost:8000').replace(/\/$/, '');
const RUNNER_TOKEN = process.env.RUNNER_TOKEN || 'perf-local-dev-token';
const RUNNER_ID = process.env.RUNNER_ID || 'win-01';
// 打包分发后 perfdog 与 agent 同目录 → 优先用自身目录；开发环境(agent 单独在 tools/)回落到源码路径。
const PERFDOG_DIR = process.env.PERFDOG_DIR || (existsSync(join(__dir, 'nami-perfdog.mjs')) ? __dir : 'D:/git/test/nami-perfdog');
const SESSIONS_DIR = join(PERFDOG_DIR, 'sessions');
const POLL_MS = Number(process.env.POLL_MS || 5000);
const REPORT_SET_ID = process.env.REPORT_SET_ID ? Number(process.env.REPORT_SET_ID) : null;  // upload 时归入的报告集(可选)

const H = { 'Content-Type': 'application/json', Authorization: `Bearer ${RUNNER_TOKEN}` };
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
const enc = encodeURIComponent;

async function api(method, path, body) {
  const res = await fetch(`${BASE_URL}${path}`, { method, headers: H, body: body ? JSON.stringify(body) : undefined });
  const txt = await res.text();
  let json;
  try { json = JSON.parse(txt); } catch { json = { code: -1, msg: txt }; }
  if (!res.ok || json.code !== 0) throw new Error(`${method} ${path} → ${res.status} ${json.msg || txt}`);
  return json.data;
}

const ndjson = (p) => (existsSync(p)
  ? readFileSync(p, 'utf8').split(/\r?\n/).filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean)
  : []);

// 按 metric 分组抽稀，每组最多 keep 点（等距），回传前压体积。
function decimate(samples, keep = 2000) {
  const byMetric = new Map();
  for (const s of samples) {
    if (!byMetric.has(s.metric)) byMetric.set(s.metric, []);
    byMetric.get(s.metric).push(s);
  }
  const out = [];
  for (const arr of byMetric.values()) {
    if (arr.length <= keep) { out.push(...arr); continue; }
    const step = arr.length / keep;
    for (let i = 0; i < keep; i++) out.push(arr[Math.floor(i * step)]);
  }
  out.sort((a, b) => a.t - b.t);
  return out;
}

function listSessionDirs() {
  if (!existsSync(SESSIONS_DIR)) return [];
  return readdirSync(SESSIONS_DIR)
    .map((d) => join(SESSIONS_DIR, d))
    .filter((p) => { try { return statSync(p).isDirectory(); } catch { return false; } });
}

function readSession(dir) {
  const metaPath = join(dir, 'meta.json');
  if (!existsSync(metaPath)) return null;
  const meta = JSON.parse(readFileSync(metaPath, 'utf8'));
  return { dir, meta, samples: decimate(ndjson(join(dir, 'samples.ndjson'))), events: ndjson(join(dir, 'events.ndjson')) };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 采集过程中每 ~1.5s tail 本次 session 的 samples.ndjson，把增量推给平台实时缓冲。
// beforeDirs：spawn 前的目录集合，用于识别本次新建的 session 目录；stop.stopped 置真即退出。
async function pushLiveLoop(runId, beforeDirs, stop) {
  let dir = null;
  let pushed = 0;
  let first = true;
  while (!stop.stopped) {
    await sleep(1500);
    if (!dir) {
      const fresh = listSessionDirs().filter((d) => !beforeDirs.has(d));
      if (fresh.length) dir = fresh.sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs)[0];
    }
    if (!dir) continue;
    const sp = join(dir, 'samples.ndjson');
    if (!existsSync(sp)) continue;
    const lines = readFileSync(sp, 'utf8').split(/\r?\n/).filter(Boolean);
    if (lines.length <= pushed) continue;
    const samples = lines.slice(pushed).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
    pushed = lines.length;
    if (!samples.length) continue;
    try {
      await api('POST', `/api/perf/queue/${runId}/live?runner=${enc(RUNNER_ID)}`, { samples, reset: first });
      first = false;
    } catch { /* 实时推送失败不影响采集主流程 */ }
  }
}

// 跑一次 perfdog run，返回新增（或最新）session 目录。beforeDirs 由调用方在 spawn 前算好。
function runPerfdog(args, beforeDirs) {
  return new Promise((resolve, reject) => {
    const child = spawn('node', ['nami-perfdog.mjs', 'run', ...args], { cwd: PERFDOG_DIR, stdio: 'inherit' });
    child.on('error', reject);
    child.on('exit', (code) => {
      const after = listSessionDirs();
      const fresh = after.filter((d) => !beforeDirs.has(d));
      const pool = fresh.length ? fresh : after;
      const pick = pool.sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs)[0];
      resolve({ code, dir: pick });
    });
  });
}

// ---- 轮询执行 dispatch 任务 ----
async function pollOnce() {
  const jobs = await api('GET', `/api/perf/queue?runner=${enc(RUNNER_ID)}&limit=5`);
  if (!jobs.length) return;
  for (const job of jobs) {
    // 只有长监控(带 duration)可真正无人值守；其余交互场景老实回传 failed，提示走 upload。
    if (job.scenario !== '长监控' || !job.duration) {
      log(`跳过 #${job.run_id} ${job.scenario}（需人工介入）`);
      await api('POST', `/api/perf/queue/${job.run_id}/claim?runner=${enc(RUNNER_ID)}`);
      await api('PATCH', `/api/perf/queue/${job.run_id}?runner=${enc(RUNNER_ID)}`, {
        outcome: 'failed',
        error: `场景「${job.scenario}」需人工按提示操作，执行机无法无人值守；请在本机用 纳米性能测试.bat 采集后 perf-agent upload 直传`,
      });
      continue;
    }
    log(`认领 #${job.run_id} 长监控/${job.variant} duration=${job.duration}`);
    await api('POST', `/api/perf/queue/${job.run_id}/claim?runner=${enc(RUNNER_ID)}`);
    let dur = String(job.duration);
    if (/^\d+$/.test(dur)) dur += 's';   // 纯数字按秒（perfdog 对无单位数字解析为 0s）
    const runArgs = ['--scenario', '长监控', '--variant', job.variant, '--duration', dur];
    if (job.proc) runArgs.push('--proc', job.proc);
    const before = new Set(listSessionDirs());
    const stop = { stopped: false };
    const liveP = pushLiveLoop(job.run_id, before, stop);   // 并发：采集中每 ~1.5s 推实时样本
    try {
      const { dir } = await runPerfdog(runArgs, before);
      stop.stopped = true;
      await liveP;
      const sess = dir ? readSession(dir) : null;
      if (!sess) throw new Error('未找到采集产物 session');
      await api('PATCH', `/api/perf/queue/${job.run_id}?runner=${enc(RUNNER_ID)}`, {
        outcome: sess.meta.outcome, meta: sess.meta, samples: sess.samples, events: sess.events,
      });
      log(`回传 #${job.run_id} ✓（${sess.samples.length} samples）`);
    } catch (e) {
      stop.stopped = true;
      await liveP.catch(() => {});
      log(`执行 #${job.run_id} 失败：${e.message}`);
      await api('PATCH', `/api/perf/queue/${job.run_id}?runner=${enc(RUNNER_ID)}`, { outcome: 'failed', error: e.message });
    }
  }
}

// ---- upload 子命令：直传本地 session ----
async function cmdUpload(target) {
  let dirs;
  if (target && target !== '--all') {
    dirs = [target.includes('/') || target.includes('\\') ? target : join(SESSIONS_DIR, target)];
  } else {
    dirs = listSessionDirs();
    if (target !== '--all') dirs = dirs.filter((d) => !existsSync(join(d, '.uploaded')));
  }
  if (!dirs.length) { log('无待上传 session（已全部打过 .uploaded 标记，或目录为空）'); return; }
  let ok = 0;
  for (const dir of dirs) {
    const sess = readSession(dir);
    if (!sess) { log('跳过（无 meta.json）：', dir); continue; }
    try {
      const data = await api('POST', `/api/perf/queue/upload?runner=${enc(RUNNER_ID)}`, {
        runner: RUNNER_ID,
        report_set_id: REPORT_SET_ID,
        scenario: sess.meta.scenario,
        variant: sess.meta.variant,
        proc: sess.meta.proc || null,
        duration: sess.meta.duration || null,
        outcome: sess.meta.outcome,
        meta: sess.meta,
        samples: sess.samples,
        events: sess.events,
      });
      writeFileSync(join(dir, '.uploaded'), String(data.id));
      ok++;
      log(`upload ✓ ${sess.meta.scenario}/${sess.meta.variant} → run#${data.id}（${sess.samples.length} samples）`);
    } catch (e) {
      log(`upload ✗ ${dir}：${e.message}`);
    }
  }
  log(`完成 ${ok}/${dirs.length}`);
}

// ---- 入口 ----
const [cmd, arg] = process.argv.slice(2);
if (cmd === 'upload') {
  await cmdUpload(arg);
} else if (cmd === 'poll-once') {
  log(`poll-once · runner=${RUNNER_ID} · ${BASE_URL}`);
  await pollOnce();
  log('done');
} else {
  log(`perf-agent 轮询启动 · runner=${RUNNER_ID} · ${BASE_URL} · 每 ${POLL_MS}ms`);
  log(`perfdog: ${PERFDOG_DIR}`);
  for (;;) {
    try { await pollOnce(); } catch (e) { log('轮询错误：', e.message); }
    await new Promise((r) => setTimeout(r, POLL_MS));
  }
}
