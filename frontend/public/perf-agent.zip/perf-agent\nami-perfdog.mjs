#!/usr/bin/env node
// nami-perfdog —— 纳米 Work Windows 客户端性能验证工具（单文件采集内核 + 报表）
//
// 参考 PerfDog：针对「每日行业动态生成 / 每周竞品监控」等高频定时任务，
// 全程监控任务从触发到完成的 FPS / CPU / GPU / 内存 / 网络延迟，落盘后出可视化报表。
//
// 设计文档：docs/superpowers/specs/2026-08-13-nami-perfdog-design.md
//
// 零运行时依赖：仅用 Node 内置能力（fetch / WebSocket / child_process）+ Windows 内置
// wmic/typeperf。无需 npm install。要求 Node >= 22（内置 WebSocket）。
//
// 前置：Namiwork.exe 必须带调试端口启动一次（Electron CDP 端口只能启动时带上）。
//   先彻底退出纳米 Work（含托盘），再用实际安装路径启动，例如：
//     & "D:\Program Files\Namiwork\Namiwork.exe" --remote-debugging-port=9222
//   安装路径因机器而异，可在“注册表卸载信息 / 开始菜单快捷方式”里查（DisplayName=纳米 Work 桌面版）。
//
// 用法：
//   node nami-perfdog.mjs list-tasks                 列出可采集的自动化任务（cron.list）
//   node nami-perfdog.mjs run --task <jobId>[,<id2>]  采集一个/多个任务（串行）
//   node nami-perfdog.mjs run --match 竞品            按任务名模糊匹配后采集
//   node nami-perfdog.mjs report [sessionsDir]        由已采集 session 生成 HTML 报表
//
// 采集内核可无头独立运行；GUI 实时仪表盘为后续增量，不在本文件内。
'use strict';

import { spawn, spawnSync } from 'node:child_process';
import { createConnection } from 'node:net';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ── 配置（可被 CLI / 环境变量覆盖）────────────────────────────────────────
const CONFIG = {
  cdpUrl: process.env.CDP_URL || 'http://127.0.0.1:9222',
  coreWs: process.env.CORE_WS || 'ws://127.0.0.1:19798',
  coreHealth: process.env.CORE_HEALTH || 'http://127.0.0.1:19798/desktop/health',
  pingHost: process.env.PING_HOST || 'api.so.n.cn',
  pingPort: Number(process.env.PING_PORT || 443),
  sampleIntervalMs: Number(process.env.SAMPLE_MS || 1000),  // 系统/JS堆采样节奏
  fpsWindowMs: 500,          // FPS 归约窗口
  pingIntervalMs: 5000,      // 环境基线探测节奏
  baselineMs: 5000,          // 触发前空闲基线段
  tailMs: 3000,              // 终态后收尾采集
  cooldownMs: 5000,          // 多任务间冷却
  heartbeatMs: 60_000,       // 长监控心跳日志节奏
  partialMetaMs: 5 * 60_000, // 长监控部分 meta 落盘节奏（崩溃兜底）
  maxDurationMs: 5 * 60_000, // 单任务超时
  readySelector: process.env.READY_SELECTOR || '.tiptap.ProseMirror, .ql-editor, [contenteditable="true"]', // 冷启动"可用"判据：输入框
  readyTimeoutMs: 45_000,    // 冷启动等关键元素就绪的上限，超时回退首屏
  sessionsDir: path.join(__dirname, 'sessions'),
  procNames: ['namiclaw.exe', 'Namiwork.exe', 'nmcore.exe'], // 进程树聚合的目标进程名（namiclaw 是纳米 Work 桌面端真实进程名）
  primaryProc: 'namiclaw.exe',               // 主进程名（场景探测用；--proc 可覆盖）
};

// ── 通用工具 ───────────────────────────────────────────────────────────
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const nowMs = () => Number(process.hrtime.bigint() / 1000n) / 1000; // 单调时钟(ms)
const log = (...a) => console.log('[perfdog]', ...a);
const warn = (...a) => console.warn('[perfdog][warn]', ...a);

// 数值统计：avg/peak/min/p5（忽略 null）
function stats(values) {
  const nums = values.filter((v) => typeof v === 'number' && Number.isFinite(v));
  if (!nums.length) return { avg: null, peak: null, min: null, p5: null, n: 0 };
  const sorted = [...nums].sort((a, b) => a - b);
  const sum = nums.reduce((s, v) => s + v, 0);
  const pct = (p) => sorted[Math.min(sorted.length - 1, Math.floor((p / 100) * sorted.length))];
  return {
    avg: +(sum / nums.length).toFixed(2),
    peak: +sorted[sorted.length - 1].toFixed(2),
    min: +sorted[0].toFixed(2),
    p5: +pct(5).toFixed(2),
    n: nums.length,
  };
}

// ── CDP 最小客户端（走 HTTP + WebSocket，不依赖 playwright）─────────────
// 连到 Namiwork.exe 的调试端口，找到承载 work.n.cn 的 renderer target，
// 用其 webSocketDebuggerUrl 直接跑 CDP 命令。
const HOST_RE = /(^|\.)(work\.n\.cn|n\.cn)/i;

async function cdpListTargets(cdpUrl) {
  const res = await fetch(`${cdpUrl}/json/list`, { signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new Error(`CDP /json/list HTTP ${res.status}`);
  return res.json();
}

// 选出承载纳米 Work 页面的 page target
function pickWorkTarget(targets) {
  const pages = targets.filter((t) => t.type === 'page' && !/devtools/i.test(t.url || ''));
  return (
    pages.find((t) => HOST_RE.test(t.url || '')) ||
    pages.find((t) => t.url && t.url !== 'about:blank') ||
    pages[0] ||
    null
  );
}

// 一个轻量 CDP 会话：发命令 + 收事件。基于 Node 内置 WebSocket。
class CdpSession {
  constructor(wsUrl) {
    this.wsUrl = wsUrl;
    this.ws = null;
    this.id = 0;
    this.pending = new Map();
    this.listeners = new Map(); // method -> [fn]
  }
  connect() {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(this.wsUrl);
      this.ws = ws;
      const to = setTimeout(() => reject(new Error('CDP ws connect timeout')), 10_000);
      ws.addEventListener('open', () => { clearTimeout(to); resolve(); });
      ws.addEventListener('error', () => { clearTimeout(to); reject(new Error('CDP ws error')); });
      ws.addEventListener('message', (ev) => this._onMessage(String(ev.data)));
      ws.addEventListener('close', () => {
        for (const { reject: rj } of this.pending.values()) rj(new Error('CDP ws closed'));
        this.pending.clear();
      });
    });
  }
  _onMessage(data) {
    let msg;
    try { msg = JSON.parse(data); } catch { return; }
    if (msg.id != null && this.pending.has(msg.id)) {
      const { resolve, reject } = this.pending.get(msg.id);
      this.pending.delete(msg.id);
      if (msg.error) reject(new Error(msg.error.message || 'CDP error'));
      else resolve(msg.result);
    } else if (msg.method) {
      for (const fn of this.listeners.get(msg.method) || []) {
        try { fn(msg.params); } catch { /* listener 抛错不影响采集 */ }
      }
    }
  }
  send(method, params = {}) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      try {
        this.ws.send(JSON.stringify({ id, method, params }));
      } catch (e) {
        this.pending.delete(id);
        reject(e);
      }
      setTimeout(() => {
        if (this.pending.has(id)) {
          this.pending.delete(id);
          reject(new Error(`CDP ${method} timeout`));
        }
      }, 15_000);
    });
  }
  on(method, fn) {
    if (!this.listeners.has(method)) this.listeners.set(method, []);
    this.listeners.get(method).push(fn);
  }
  close() { try { this.ws?.close(); } catch { /* ignore */ } }
}

// ── 探测原语：进程 / 端口 / 窗口轮询（供杀进程/冷启动/热启动场景复用）──────
// 全部只“观测”系统状态、不执行任何动作，契合“你手动操作、工具只记录”。

// 一次性查某进程名的 pid 列表（Windows）。返回 number[]。
function queryPids(procName) {
  const base = procName.replace(/\.exe$/i, '');
  const res = spawnSync('powershell.exe',
    ['-NoProfile', '-NonInteractive', '-Command',
     `$p=Get-Process -Name '${base}' 2>$null; if($p){($p|Select-Object -ExpandProperty Id) -join ','}`],
    { encoding: 'utf8', windowsHide: true });
  const out = (res.stdout || '').trim();
  if (!out) return [];
  return out.split(',').map((s) => parseInt(s.trim(), 10)).filter(Number.isFinite);
}

// 轮询直到进程“出现”（首次探到 ≥1 个 pid）。返回 {ok, atMs, pids}。
async function waitProcAppear(procName, clock, { timeoutMs = 120_000, pollMs = 200, signal } = {}) {
  const deadline = nowMs() + timeoutMs;
  while (nowMs() < deadline && !signal?.aborted) {
    const pids = queryPids(procName);
    if (pids.length) return { ok: true, atMs: clock(), pids };
    await sleep(pollMs);
  }
  return { ok: false, atMs: clock(), pids: [] };
}

// 轮询直到进程“全部消失”。返回 {ok, atMs}。
async function waitProcGone(procName, clock, { timeoutMs = 60_000, pollMs = 200 } = {}) {
  const deadline = nowMs() + timeoutMs;
  while (nowMs() < deadline) {
    if (queryPids(procName).length === 0) return { ok: true, atMs: clock() };
    await sleep(pollMs);
  }
  return { ok: false, atMs: clock() };
}

// 轮询直到 CDP 端口就绪（/json/version 可达且返回 webSocketDebuggerUrl）。返回 {ok, atMs}。
async function waitCdpReady(cdpUrl, clock, { timeoutMs = 60_000, pollMs = 300, signal } = {}) {
  const deadline = nowMs() + timeoutMs;
  while (nowMs() < deadline && !signal?.aborted) {
    try {
      const res = await fetch(`${cdpUrl}/json/version`, { signal: AbortSignal.timeout(2000) });
      if (res.ok) { const j = await res.json(); if (j.webSocketDebuggerUrl) return { ok: true, atMs: clock() }; }
    } catch { /* 端口未起，继续轮询 */ }
    await sleep(pollMs);
  }
  return { ok: false, atMs: clock() };
}

// 轮询直到出现承载目标页面的 renderer target 且其 URL 非 about:blank（≈首屏 DOM 就绪）。
async function waitFirstPage(cdpUrl, clock, { timeoutMs = 60_000, pollMs = 300, signal } = {}) {
  const deadline = nowMs() + timeoutMs;
  while (nowMs() < deadline && !signal?.aborted) {
    try {
      const targets = await cdpListTargets(cdpUrl);
      const t = pickWorkTarget(targets);
      if (t && t.url && t.url !== 'about:blank') return { ok: true, atMs: clock(), url: t.url };
    } catch { /* 继续 */ }
    await sleep(pollMs);
  }
  return { ok: false, atMs: clock() };
}

// 查某进程是否有“前台/可见主窗口”（热启动激活判定）。用 MainWindowHandle≠0 近似。
function queryHasVisibleWindow(procName) {
  const base = procName.replace(/\.exe$/i, '');
  const res = spawnSync('powershell.exe',
    ['-NoProfile', '-NonInteractive', '-Command',
     `$p=Get-Process -Name '${base}' 2>$null | Where-Object { $_.MainWindowHandle -ne 0 }; if($p){'1'}else{'0'}`],
    { encoding: 'utf8', windowsHide: true });
  return (res.stdout || '').trim() === '1';
}

// 轮询直到目标进程出现可见主窗口（热启动：从后台/最小化到激活）。返回 {ok, atMs}。
async function waitWindowActive(procName, clock, { timeoutMs = 30_000, pollMs = 200 } = {}) {
  const deadline = nowMs() + timeoutMs;
  while (nowMs() < deadline) {
    if (queryHasVisibleWindow(procName)) return { ok: true, atMs: clock() };
    await sleep(pollMs);
  }
  return { ok: false, atMs: clock() };
}

// 前台窗口探测器（热启动激活判定）：常驻 PowerShell 用 Win32 GetForegroundWindow 流式吐
// 「当前前台进程是否目标进程」。一次性付 Add-Type 编译成本(~2-3s)，之后 ~500ms/行、不阻塞事件循环。
// 比 MainWindowHandle≠0 准：能区分"后台/最小化"与"真正切到前台"。返回 { isForeground(), stop() }。
function makeForegroundProbe(procName) {
  const base = procName.replace(/\.exe$/i, '');
  const state = { fg: false };
  const psScript = `
$ErrorActionPreference='SilentlyContinue'
Add-Type @"
using System;using System.Runtime.InteropServices;
public class FGWin {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
}
"@
while ($true) {
  $h=[FGWin]::GetForegroundWindow(); $procId=0; [void][FGWin]::GetWindowThreadProcessId($h,[ref]$procId)
  $n=''; try { $n=(Get-Process -Id $procId).ProcessName } catch {}
  if ($n -eq '${base}') { Write-Output '1' } else { Write-Output '0' }
  Start-Sleep -Milliseconds 400
}
`.trim();
  const ps = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', psScript], { windowsHide: true });
  let buf = '';
  ps.stdout.on('data', (d) => {
    buf += d.toString('utf8');
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (line === '1' || line === '0') state.fg = line === '1';
    }
  });
  ps.on('error', () => { /* 前台探测不可用时降级为纯回车确认 */ });
  return { isForeground: () => state.fg, stop() { try { ps.kill(); } catch { /* ignore */ } } };
}

// 异步轮询前台探测器的内存标志直到目标成为前台（不 spawn、不阻塞）。返回 {ok, atMs}。
async function waitForegroundActive(probe, clock, { timeoutMs = 30_000, pollMs = 200, signal } = {}) {
  const deadline = nowMs() + timeoutMs;
  while (nowMs() < deadline && !signal?.aborted) {
    if (probe.isForeground()) return { ok: true, atMs: clock() };
    await sleep(pollMs);
  }
  return { ok: false, atMs: clock() };
}

// 轮询直到关键业务元素渲染出来（冷启动"可用"判据）。返回 {ok, atMs}。
// 真身在 VM 子 iframe，顶层 querySelector 够不到且跨域不能 pierce：开 CDP 会话、
// Runtime.enable 收集所有执行上下文，在各 context 内 querySelector（穿透 iframe）。
async function waitReadyElement(cdpUrl, selector, clock, { timeoutMs = 45_000, pollMs = 400, signal } = {}) {
  let sess = null;
  try {
    const target = pickWorkTarget(await cdpListTargets(cdpUrl));
    if (!target?.webSocketDebuggerUrl) return { ok: false, atMs: clock() };
    sess = new CdpSession(target.webSocketDebuggerUrl);
    await sess.connect();
    const ctxIds = new Set();
    sess.on('Runtime.executionContextCreated', (p) => { if (p.context?.id != null) ctxIds.add(p.context.id); });
    sess.on('Runtime.executionContextDestroyed', (p) => { if (p.executionContextId != null) ctxIds.delete(p.executionContextId); });
    sess.on('Runtime.executionContextsCleared', () => ctxIds.clear());
    await sess.send('Runtime.enable');
    const expr = `!!document.querySelector(${JSON.stringify(selector)})`;
    const hit = async (contextId) => {
      try {
        const r = await sess.send('Runtime.evaluate', { expression: expr, returnByValue: true, ...(contextId != null ? { contextId } : {}) });
        return r?.result?.value === true;
      } catch { return false; }
    };
    const deadline = nowMs() + timeoutMs;
    while (nowMs() < deadline && !signal?.aborted) {
      if (await hit(null)) return { ok: true, atMs: clock() };            // 顶层
      for (const id of [...ctxIds]) if (await hit(id)) return { ok: true, atMs: clock() }; // 各 iframe 上下文
      await sleep(pollMs);
    }
    return { ok: false, atMs: clock() };
  } catch {
    return { ok: false, atMs: clock() };
  } finally {
    try { sess?.close(); } catch { /* ignore */ }
  }
}

// ── collector-cdp：FPS / JS 堆 / 传输层延迟 ──────────────────────────────
// 返回一个采集器句柄；失败时 available=false，其它两路照跑（部分降级原则）。
async function makeCdpCollector(clock, onSample) {
  const collector = { available: false, session: null, wsRtts: [], stop() {} };
  let targets;
  try {
    targets = await cdpListTargets(CONFIG.cdpUrl);
  } catch (e) {
    warn(`CDP 连接失败（${CONFIG.cdpUrl}）：${e.message}`);
    warn('  请先彻底退出纳米 Work（含托盘），再用实际安装路径带调试端口启动，例如：');
    warn('    & "D:\\Program Files\\Namiwork\\Namiwork.exe" --remote-debugging-port=9222');
    warn('  FPS / renderer 指标本轮不可用；系统级与 core 两路继续。');
    return collector;
  }
  const target = pickWorkTarget(targets);
  if (!target?.webSocketDebuggerUrl) {
    warn('CDP 已连上但未找到 work.n.cn 窗口；FPS/renderer 不可用。');
    return collector;
  }
  const sess = new CdpSession(target.webSocketDebuggerUrl);
  try {
    await sess.connect();
    await sess.send('Performance.enable');
    await sess.send('Network.enable');
    await sess.send('Runtime.enable');
    await sess.send('Page.enable');
  } catch (e) {
    warn(`CDP 域启用失败：${e.message}；FPS/renderer 不可用。`);
    sess.close();
    return collector;
  }
  collector.session = sess;
  collector.available = true;
  collector.rendererPid = target.webSocketDebuggerUrl && await cdpRendererPid(sess).catch(() => null);

  // 注入 rAF FPS 计数器（页面里维护一个滑动帧时间戳窗口）
  const injectFps = async () => {
    await sess.send('Runtime.evaluate', {
      expression: `(() => {
        if (window.__perfdogFps) return;
        window.__perfdogFrames = [];
        const loop = (t) => {
          window.__perfdogFrames.push(t);
          if (window.__perfdogFrames.length > 240) window.__perfdogFrames.shift();
          requestAnimationFrame(loop);
        };
        requestAnimationFrame(loop);
        window.__perfdogFps = true;
      })()`,
    }).catch(() => {});
  };
  await injectFps();
  // 导航后重新注入
  sess.on('Page.frameNavigated', (p) => { if (!p.frame?.parentId) injectFps(); });

  // 传输层延迟：Network 请求往返
  const reqStart = new Map();
  sess.on('Network.requestWillBeSent', (p) => reqStart.set(p.requestId, p.timestamp));
  sess.on('Network.responseReceived', (p) => {
    const t0 = reqStart.get(p.requestId);
    if (t0 != null && p.timestamp != null) {
      const rttMs = (p.timestamp - t0) * 1000;
      if (rttMs >= 0 && rttMs < 120_000) {
        collector.wsRtts.push(rttMs);
        onSample({ t: clock(), source: 'cdp', metric: 'netRttMs', value: +rttMs.toFixed(1) });
      }
    }
    reqStart.delete(p.requestId);
  });

  // 定时采 FPS + JS 堆
  let fpsTimer = null;
  let heapTimer = null;
  const sampleFps = async () => {
    try {
      const r = await sess.send('Runtime.evaluate', {
        expression: `(() => {
          const f = window.__perfdogFrames || [];
          if (f.length < 2) return null;
          const now = performance.now();
          const recent = f.filter((t) => now - t <= 1000);
          return recent.length;
        })()`,
        returnByValue: true,
      });
      const fps = r?.result?.value;
      if (typeof fps === 'number') onSample({ t: clock(), source: 'cdp', metric: 'fps', value: fps });
    } catch { /* 单次采样失败记 null（不采即断点） */ }
  };
  const sampleHeap = async () => {
    try {
      const r = await sess.send('Performance.getMetrics');
      const m = Object.fromEntries((r.metrics || []).map((x) => [x.name, x.value]));
      if (m.JSHeapUsedSize != null) {
        onSample({ t: clock(), source: 'cdp', metric: 'jsHeapMB', value: +(m.JSHeapUsedSize / 1048576).toFixed(1) });
      }
      if (m.Nodes != null) onSample({ t: clock(), source: 'cdp', metric: 'domNodes', value: m.Nodes });
    } catch { /* ignore */ }
  };
  fpsTimer = setInterval(sampleFps, CONFIG.fpsWindowMs);
  heapTimer = setInterval(sampleHeap, CONFIG.sampleIntervalMs);

  collector.stop = () => {
    clearInterval(fpsTimer);
    clearInterval(heapTimer);
    sess.close();
  };
  return collector;
}

// 取 renderer 进程 pid（供系统级采集把 renderer 纳入进程树；失败返回 null）
async function cdpRendererPid(sess) {
  try {
    const r = await sess.send('SystemInfo.getProcessInfo').catch(() => null);
    if (r?.processInfo?.length) return r.processInfo[0].id;
  } catch { /* SystemInfo 未必可用 */ }
  return null;
}

// ── collector-system：进程树 CPU / GPU / 整机内存（Windows 内置计数器）──
// 单文件零依赖版走 PowerShell Get-Counter / Get-Process（比 koffi+pdh.dll 简单，
// 设计文档 §4 允许此降级）。按进程名聚合整个进程树。
async function makeSystemCollector(clock, onSample) {
  const collector = { available: process.platform === 'win32', gpuAvailable: true, stop() {} };
  if (process.platform !== 'win32') {
    warn('非 Windows 平台，系统级采集不可用（CPU/GPU/整机内存）。');
    collector.available = false;
    return collector;
  }
  const numCpu = os.cpus().length || 1;
  const names = CONFIG.procNames.map((n) => n.replace(/\.exe$/i, ''));
  const intervalSec = Math.max(1, Math.round(CONFIG.sampleIntervalMs / 1000));

  // 常驻 PowerShell：一个进程内循环采样、逐行流式吐出 `cpu|mem|gpu|count`。
  // 关键修复（旧实现每周期 spawn 一次，冷启动+Get-Counter 采样共 ~3s，远超 1s 间隔、
  // 且内联参数走样导致 CPU 恒 0）：
  //   - CPU 用 Get-Counter 连续采两拍取后一拍（进程级 % Processor Time 需归一到逻辑核数）；
  //   - 用计数器 pathname 的本地化名，直接用英文路径在中文系统也可用（PDH 英文路径通用）；
  //   - 单进程常驻，避免每拍付冷启动成本；stdout 按行解析。
  const names_ps = names.map((n) => `'${n}'`).join(',');
  const psScript = `
$ErrorActionPreference='SilentlyContinue'
$OutputEncoding=[Console]::OutputEncoding=[Text.Encoding]::ASCII
$names=@(${names_ps})
$paths=$names | ForEach-Object { "\\Process($_*)\\% Processor Time" }
while ($true) {
  $procs = Get-Process -Name $names 2>$null
  $pids = @($procs | Select-Object -ExpandProperty Id)
  $memMB = [math]::Round((($procs | Measure-Object WorkingSet64 -Sum).Sum)/1MB, 1)
  $cpu = 'NA'
  try {
    $s = (Get-Counter -Counter $paths -ErrorAction Stop).CounterSamples
    $cpu = [math]::Round((($s | Measure-Object CookedValue -Sum).Sum)/${numCpu}, 1)
  } catch {}
  $gpu = 'NA'
  try {
    $g = (Get-Counter -Counter '\\GPU Engine(*engtype_3D)\\Utilization Percentage' -ErrorAction Stop).CounterSamples
    $sum = 0.0
    foreach ($x in $g) { foreach ($p in $pids) { if ($x.InstanceName -like ('pid_' + $p + '*')) { $sum += $x.CookedValue } } }
    $gpu = [math]::Round($sum, 1)
  } catch {}
  Write-Output ("{0}|{1}|{2}|{3}" -f $cpu, $memMB, $gpu, $pids.Count)
  Start-Sleep -Seconds ${intervalSec}
}
`.trim();

  const ps = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', psScript], { windowsHide: true });
  let buf = '';
  let gotAny = false;
  const handleLine = (line) => {
    const parts = line.trim().split('|');
    if (parts.length !== 4) return;
    const t = clock();
    const [cpu, mem, gpu, pidCount] = parts;
    const cpuN = parseFloat(cpu), memN = parseFloat(mem), gpuN = parseFloat(gpu);
    if (Number.isFinite(cpuN)) { onSample({ t, source: 'system', metric: 'cpuPct', value: cpuN }); gotAny = true; }
    if (Number.isFinite(memN)) { onSample({ t, source: 'system', metric: 'memMB', value: memN }); gotAny = true; }
    if (Number.isFinite(gpuN)) onSample({ t, source: 'system', metric: 'gpuPct', value: gpuN });
    else if (collector.gpuAvailable && (gpu === 'NA' || gpu === '')) {
      collector.gpuAvailable = false;
      warn('GPU 计数器不可用（无独显/驱动不出 engtype_3D 计数器），GPU 曲线标为不可用。');
    }
    const pc = parseInt(pidCount, 10);
    if (Number.isFinite(pc)) onSample({ t, source: 'system', metric: 'procCount', value: pc });
  };
  ps.stdout.on('data', (d) => {
    buf += d.toString('utf8');
    let idx;
    while ((idx = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, idx);
      buf = buf.slice(idx + 1);
      if (line.trim()) handleLine(line);
    }
  });
  ps.on('error', (e) => warn(`系统采集进程启动失败：${e.message}`));

  // 首拍校验：Get-Counter 首次预热较慢（~3s/拍），放宽到 ~5s 再判首拍，避免误报。
  await sleep(Math.min(6000, CONFIG.sampleIntervalMs + 4500));
  if (!gotAny) warn('系统采集首拍未出数（CPU/内存），将继续尝试；若持续为空请检查 PowerShell 可用性。');

  collector.stop = () => { try { ps.kill(); } catch { /* ignore */ } };
  return collector;
}

// ── nmcore WS 客户端（v3 握手 + 方法调用 + 事件订阅）─────────────────────
// 协议 v3：连上后服务器推 connect.challenge → 客户端发 connect{minProtocol:3,maxProtocol:3}
// → 收 hello-ok。随后可发 {type:'req',id,method,params}，收 {type:'res',id,ok,result|error}
// 与事件 {type:'event',event,payload}。
class CoreClient {
  constructor(wsUrl) {
    this.wsUrl = wsUrl;
    this.ws = null;
    this.reqId = 0;
    this.pending = new Map();
    this.eventHandlers = [];
    this.ready = false;
  }
  connect() {
    return new Promise((resolve, reject) => {
      let ws;
      // nmcore 对 WS 做 Origin 白名单校验（见 desktop 的 claw-ws-origin.js）：裸连收到非 101 被拒。
      // 必须带 Origin=http://<host>:<port>（与本地 nmcore 地址同源）才放行握手。
      const origin = this.wsUrl.replace(/^ws:/, 'http:').replace(/^wss:/, 'https:').replace(/\/+$/, '');
      try { ws = new WebSocket(this.wsUrl, { headers: { Origin: origin } }); } catch (e) { reject(e); return; }
      this.ws = ws;
      const to = setTimeout(() => reject(new Error('core ws connect timeout')), 10_000);
      ws.addEventListener('error', () => { clearTimeout(to); reject(new Error('core ws error')); });
      ws.addEventListener('close', () => {
        for (const { reject: rj } of this.pending.values()) rj(new Error('core ws closed'));
        this.pending.clear();
      });
      ws.addEventListener('message', (ev) => {
        let f; try { f = JSON.parse(String(ev.data)); } catch { return; }
        // 握手：收到 challenge 就回 connect
        if (f.type === 'event' && f.event === 'connect.challenge') {
          this._sendRaw({ type: 'req', id: 'connect-1', method: 'connect', params: { minProtocol: 3, maxProtocol: 3 } });
          return;
        }
        if ((f.type === 'res' && f.id === 'connect-1') || f.type === 'hello-ok') {
          if (!this.ready) { this.ready = true; clearTimeout(to); resolve(); }
          return;
        }
        if (f.type === 'res' && this.pending.has(f.id)) {
          const { resolve: rs, reject: rj } = this.pending.get(f.id);
          this.pending.delete(f.id);
          if (f.ok === false || f.error) rj(new Error(JSON.stringify(f.error || 'core error')));
          // nmcore 的成功响应体在 f.payload（实测），兼容个别用 result 的方法。
          else rs(f.payload ?? f.result ?? f);
          return;
        }
        if (f.type === 'event') for (const fn of this.eventHandlers) { try { fn(f); } catch { /* ignore */ } }
      });
      // 某些实现握手完成后不额外发 hello-ok，给个兜底：open 后若 challenge 未来也尝试直接 connect
      ws.addEventListener('open', () => {
        setTimeout(() => {
          if (!this.ready) this._sendRaw({ type: 'req', id: 'connect-1', method: 'connect', params: { minProtocol: 3, maxProtocol: 3 } });
        }, 500);
      });
    });
  }
  _sendRaw(obj) { try { this.ws.send(JSON.stringify(obj)); } catch { /* ignore */ } }
  call(method, params = {}) {
    const id = `req-${++this.reqId}`;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this._sendRaw({ type: 'req', id, method, params });
      setTimeout(() => { if (this.pending.has(id)) { this.pending.delete(id); reject(new Error(`core ${method} timeout`)); } }, 15_000);
    });
  }
  onEvent(fn) { this.eventHandlers.push(fn); }
  close() { try { this.ws?.close(); } catch { /* ignore */ } }
}

// 环境网络基线：TCP connect 握手延迟
function tcpPing(host, port, timeoutMs = 4000) {
  return new Promise((resolve) => {
    const t0 = nowMs();
    const sock = createConnection({ host, port });
    let done = false;
    const finish = (val) => { if (done) return; done = true; try { sock.destroy(); } catch {} resolve(val); };
    sock.setTimeout(timeoutMs);
    sock.on('connect', () => finish(+(nowMs() - t0).toFixed(1)));
    sock.on('timeout', () => finish(null));
    sock.on('error', () => finish(null));
  });
}

// ── 任务多信号判定状态机（纯逻辑，喂信号 → 吐状态迁移）────────────────
// 状态：IDLE → TRIGGERED → RUNNING → COMPLETED | FAILED | TIMEOUT
// 收敛：起点取触发时刻 T0；终点以 WS final 为准，DOM 完成态作 fallback，两者都有取较晚者。
function createStateMachine(jobId, clock) {
  const sessionKeyRe = new RegExp(`:cron:${jobId}:run:`);
  let state = 'IDLE';
  const marks = {}; // phase -> t
  let finalAt = null, domDoneAt = null;

  const mark = (phase, t = clock()) => { if (marks[phase] == null) marks[phase] = t; };

  return {
    get state() { return state; },
    get marks() { return marks; },
    triggered() { state = 'TRIGGERED'; mark('triggered'); },
    // 判断某个 WS 事件是否属于本任务并推进状态。返回 true 表示进入终态。
    onCoreEvent(f) {
      const p = f.payload || {};
      const sk = p.sessionKey || '';
      const belongs = !jobId || sessionKeyRe.test(sk);
      if (f.event === 'chat') {
        if (!belongs) return false;
        if (p.state === 'delta' && state === 'TRIGGERED') { state = 'RUNNING'; mark('running'); }
        if (p.state === 'final') { finalAt = clock(); mark('final', finalAt); return this._maybeComplete(); }
        if (p.state === 'error' || p.state === 'aborted') { state = 'FAILED'; mark('final'); return true; }
      }
      if (f.event === 'agent' && belongs && state === 'TRIGGERED') { state = 'RUNNING'; mark('running'); }
      return false;
    },
    onFirstToken(ttftMs) { mark('first-token'); this.ttftMs = ttftMs; },
    onStep(name, t) { mark(`step:${name}`, t); },
    // DOM 从 loading→完成态（CDP 侧探测），作为兜底/双保险
    onDomComplete() { domDoneAt = clock(); return this._maybeComplete(); },
    _maybeComplete() {
      // 终点取 final 与 DOM 完成的较晚者；只要有 final 即可判完成（DOM 缺失时）
      if (state === 'COMPLETED' || state === 'FAILED') return false;
      if (finalAt != null) { state = 'COMPLETED'; return true; }
      return false;
    },
    timeout() { if (state !== 'COMPLETED' && state !== 'FAILED') state = 'TIMEOUT'; },
    endTs() { return Math.max(finalAt ?? 0, domDoneAt ?? 0) || clock(); },
  };
}

// 等待用户按一次回车（返回 Promise）。用于手动模式框定起止。
function waitEnter(promptText) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(promptText, () => { rl.close(); resolve(); });
  });
}

// ── 共享采集骨架：启动三路采集器 + ping + core 事件旁听，返回句柄 ────────
// 自动模式(collectTask)与手动模式(collectManual)复用。onCoreEvent 让调用方按需接状态机。
async function startCollectors({ rel, onSample, pushEvent, onCoreEvent, core }) {
  // 采集器统一传【绝对时钟 nowMs】：onSample 内部再统一减 t0abs 归一到相对时间。
  // （曾用 rel 传入导致双重扣减：rel 已减过 t0abs，onSample 又减一次 → 负的天文数字时间戳，
  //  样本全落在聚合时间窗口外 → summary 全 null。三路必须同一时钟契约。）
  const [cdp, sys] = await Promise.all([
    makeCdpCollector(nowMs, onSample),
    makeSystemCollector(nowMs, onSample),
  ]);
  const stepInfo = { steps: [], ttftMs: null, coreDurationMs: null };
  // core 可为 null（竞品对象无 nmcore）：此时跳过任务/step 事件订阅，仅系统级+CDP。
  if (core) core.onEvent((f) => {
    const p = f.payload || {};
    if (p.ttftMs != null && stepInfo.ttftMs == null) { stepInfo.ttftMs = p.ttftMs; pushEvent('first-token', p.ttftMs); }
    if (p.durationMs != null) stepInfo.coreDurationMs = p.durationMs;
    if (f.event === 'tool' && p.toolName) { pushEvent(`step:${p.toolName}`, p.phase); stepInfo.steps.push({ name: p.toolName, t: rel() }); }
    if (onCoreEvent) onCoreEvent(f);
  });
  const pingTimer = setInterval(async () => {
    const rtt = await tcpPing(CONFIG.pingHost, CONFIG.pingPort);
    onSample({ t: nowMs(), source: 'ping', metric: 'pingMs', value: rtt });
  }, CONFIG.pingIntervalMs);
  return {
    cdp, sys, stepInfo,
    stop() { clearInterval(pingTimer); cdp.stop(); sys.stop(); },
  };
}

// 建一个 session 的采集上下文（时钟/样本/事件缓冲）
function newSessionCtx() {
  const startEpoch = Date.now();
  const t0abs = nowMs();
  const rel = () => +(nowMs() - t0abs).toFixed(1);
  const samples = [];
  const events = [];
  const onSample = (s) => samples.push({ ...s, t: +(s.t - t0abs).toFixed(1) });
  const pushEvent = (phase, detail) => events.push({ t: rel(), phase, detail: detail ?? null });
  return { startEpoch, rel, samples, events, onSample, pushEvent };
}

// 长监控专用：流式落盘上下文（内存只留运行态 tally，样本即时 append）
function newStreamingSessionCtx(dir, startEpoch) {
  const t0abs = nowMs();
  const rel = () => +(nowMs() - t0abs).toFixed(1);
  const sampleStream = fs.createWriteStream(path.join(dir, 'samples.ndjson'), { flags: 'a' });
  const eventStream = fs.createWriteStream(path.join(dir, 'events.ndjson'), { flags: 'a' });
  const tally = new Map(); // metric -> {sum,count,min,max}
  const events = [];
  const onSample = (s) => {
    const t = +(s.t - t0abs).toFixed(1);
    sampleStream.write(JSON.stringify({ ...s, t }) + '\n');
    if (typeof s.value === 'number' && Number.isFinite(s.value)) {
      let a = tally.get(s.metric);
      if (!a) { a = { sum: 0, count: 0, min: Infinity, max: -Infinity }; tally.set(s.metric, a); }
      a.sum += s.value; a.count++;
      if (s.value < a.min) a.min = s.value;
      if (s.value > a.max) a.max = s.value;
    }
  };
  const pushEvent = (phase, detail) => {
    const e = { t: rel(), phase, detail: detail ?? null };
    events.push(e);
    eventStream.write(JSON.stringify(e) + '\n');
  };
  const close = () => new Promise((resolve) => {
    let pending = 2;
    const done = () => { if (--pending === 0) resolve(); };
    sampleStream.end(done); eventStream.end(done);
  });
  return { startEpoch, t0abs, rel, tally, events, onSample, pushEvent, close };
}

// 流式回读 samples.ndjson（结尾算精确 summary 用）
async function readSamplesFromDisk(dir) {
  const out = [];
  const rl = readline.createInterface({ input: fs.createReadStream(path.join(dir, 'samples.ndjson')), crlfDelay: Infinity });
  for await (const line of rl) {
    const s = line.trim();
    if (!s) continue;
    try { out.push(JSON.parse(s)); } catch { /* 跳过半行/损坏行 */ }
  }
  return out;
}

// 时长格式化：ms → '2h13m05s'
function fmtDur(ms) {
  let s = Math.max(0, Math.round(ms / 1000));
  const h = Math.floor(s / 3600); s -= h * 3600;
  const m = Math.floor(s / 60); s -= m * 60;
  const parts = [];
  if (h) parts.push(h + 'h');
  if (h || m) parts.push(m + 'm');
  parts.push(s + 's');
  return parts.join('');
}

// 心跳摘要：从运行态 tally 拼一行人话
function heartbeatLine(tally, elapsedMs) {
  const g = (k) => tally.get(k);
  const avg = (a) => (a && a.count ? +(a.sum / a.count).toFixed(1) : null);
  const cpu = g('cpuPct'), mem = g('memMB'), fps = g('fps');
  const parts = [`已跑 ${fmtDur(elapsedMs)}`];
  if (cpu) parts.push(`CPU 均${avg(cpu)}%/峰${+cpu.max.toFixed(1)}%`);
  if (mem) parts.push(`内存 ${Math.round(mem.min)}→${Math.round(mem.max)}MB`);
  if (fps) parts.push(`FPS ${avg(fps)}`);
  let total = 0; for (const a of tally.values()) total += a.count;
  parts.push(`样本 ${total}`);
  return parts.join(' ｜');
}

// 内存趋势：活跃段末 10% 时间窗均值 − 首 10% 时间窗均值（MB）。样本不足返回 null。
function memTrend(samples, baselineEndRel, taskEndRel) {
  const mem = samples.filter((s) => s.metric === 'memMB' && s.t >= baselineEndRel && s.t <= taskEndRel && typeof s.value === 'number');
  if (mem.length < 20) return null;
  const span = Math.max(1, taskEndRel - baselineEndRel);
  const firstCut = baselineEndRel + span * 0.1, lastCut = baselineEndRel + span * 0.9;
  const head = mem.filter((s) => s.t <= firstCut).map((s) => s.value);
  const tail = mem.filter((s) => s.t >= lastCut).map((s) => s.value);
  if (!head.length || !tail.length) return null;
  const avg = (a) => a.reduce((x, y) => x + y, 0) / a.length;
  return +(avg(tail) - avg(head)).toFixed(1);
}

// 部分 meta.json（崩溃兜底）：用运行态 tally，outcome:"running"
async function writePartialMeta(dir, ctx, scenario, variant, baselineEndRel) {
  const t = ctx.tally;
  const avg = (m) => { const a = t.get(m); return a && a.count ? +(a.sum / a.count).toFixed(2) : null; };
  const peak = (m) => { const a = t.get(m); return a && Number.isFinite(a.max) ? +a.max.toFixed(2) : null; };
  let total = 0; for (const a of t.values()) total += a.count;
  const partial = {
    schemaVersion: 2, jobId: `monitor-${variant}`, taskName: `长监控:${variant}`,
    trigger: 'monitor', scenario, variant, startedAt: ctx.startEpoch,
    endedAt: ctx.startEpoch + Math.round(ctx.rel()), outcome: 'running',
    durations: { totalMs: Math.round(ctx.rel() - baselineEndRel) },
    summary: {
      cpu: { avg: avg('cpuPct'), peak: peak('cpuPct') },
      gpu: { peak: peak('gpuPct') },
      mem: { avg: avg('memMB'), peak: peak('memMB') },
      fps: { avg: avg('fps') },
      net: { wsRttAvg: avg('netRttMs'), pingAvg: avg('pingMs') },
    },
    sampleCount: total,
  };
  await fsp.writeFile(path.join(dir, 'meta.json'), JSON.stringify(partial, null, 2)).catch(() => {});
}

// ── orchestrator：自动模式——采集一个 cron 任务的完整 session ────────────
async function collectTask({ jobId, taskName, core, trigger, scenario, variant }) {
  const ctx = newSessionCtx();
  const { rel, samples, events, onSample, pushEvent } = ctx;
  log(`=== 采集任务 ${taskName || jobId} (${jobId}) ===`);
  const sm = createStateMachine(jobId, rel);

  const h = await startCollectors({
    rel, onSample, pushEvent, core,
    onCoreEvent: (f) => {
      const before = sm.state;
      const term = sm.onCoreEvent(f);
      if (before !== sm.state) pushEvent(sm.state.toLowerCase(), f.payload?.state);
      if (f.payload?.ttftMs != null) sm.onFirstToken(f.payload.ttftMs);
      if (term) log(`  状态机进入终态：${sm.state}`);
    },
  });

  // ① 基线段
  pushEvent('baseline-start');
  log(`  采集空闲基线 ${CONFIG.baselineMs}ms ...`);
  await sleep(CONFIG.baselineMs);
  const baselineEndRel = rel();

  // ② 触发
  pushEvent('triggered', trigger);
  sm.triggered();
  log(`  触发任务（${trigger}）...`);
  try {
    if (trigger === 'rpc') await core.call('cron.run', { id: jobId, mode: 'force' });
  } catch (e) {
    warn(`  cron.run 触发失败：${e.message}（继续等待信号，可能已由其它途径触发）`);
  }

  // ③ 等终态或超时
  const deadline = nowMs() + CONFIG.maxDurationMs;
  while (nowMs() < deadline) {
    if (sm.state === 'COMPLETED' || sm.state === 'FAILED') break;
    await sleep(300);
  }
  if (sm.state !== 'COMPLETED' && sm.state !== 'FAILED') { sm.timeout(); pushEvent('timeout'); warn('  任务超时无终态。'); }
  const taskEndRel = sm.endTs();

  // ④ 收尾
  log(`  收尾采集 ${CONFIG.tailMs}ms ...`);
  await sleep(CONFIG.tailMs);
  pushEvent('tail-end');
  h.stop();

  const outcome = sm.state === 'COMPLETED' ? 'completed' : sm.state === 'FAILED' ? 'failed' : 'timeout';
  return finalizeSession({ ctx, jobId, taskName, trigger, baselineEndRel, taskEndRel, outcome, h, scenario: scenario || '自动化任务', variant });
}

// ── orchestrator：手动模式——两次回车框定起止 ──────────────────────────
async function collectManual({ core, taskName, scenario, variant, prompts }) {
  const ctx = newSessionCtx();
  const { rel, onSample, pushEvent } = ctx;
  const P = prompts || {}; // 提示语可按场景覆盖（如首次安装），默认沿用对话措辞
  const label = taskName || `manual-${new Date().toISOString().slice(11, 19)}`;
  log(`=== 手动采集：${label}  [${scenario || '对话'}/${variant || 'default'}] ===`);
  const h = await startCollectors({ rel, onSample, pushEvent, core }); // 不接状态机，core 事件仅旁听记录

  // ① 基线段（自动）
  pushEvent('baseline-start');
  log(`  正在采集空闲基线 ${CONFIG.baselineMs}ms（先别操作）...`);
  await sleep(CONFIG.baselineMs);

  // ② 第一次回车 = 任务开始
  await waitEnter(P.start || '\n  ▶ 基线已采完。去客户端准备好后，按【回车】开始任务采集...');
  pushEvent('triggered', 'manual');
  const startRel = rel();
  log(P.startedHint || '  ⏺ 已开始采集。现在去客户端发起对话/操作。完成后回到这里。');

  // ③ 第二次回车 = 任务结束
  await waitEnter(P.stop || '  ⏹ 任务完成后，按【回车】结束采集...');
  const taskEndRel = rel();
  pushEvent('final', 'manual-stop');
  log(`  已结束，任务段时长 ${Math.round(taskEndRel - startRel)}ms。`);

  // ④ 收尾
  log(`  收尾采集 ${CONFIG.tailMs}ms ...`);
  await sleep(CONFIG.tailMs);
  pushEvent('tail-end');
  h.stop();

  // 手动模式起点用第一次回车时刻（baseline 之后即任务段）
  return finalizeSession({
    ctx, jobId: label, taskName: label, trigger: 'manual',
    baselineEndRel: startRel, taskEndRel, outcome: 'completed', h,
    scenario: scenario || '对话', variant,
  });
}

// ── orchestrator：场景「杀进程」——你手动关，工具轮询进程消失计时 ────────
async function collectKill({ core, scenario, variant }) {
  const ctx = newSessionCtx();
  const { rel, onSample, pushEvent } = ctx;
  const proc = CONFIG.primaryProc;
  log(`=== 杀进程采集：${proc}  [${scenario}/${variant}] ===`);
  const h = await startCollectors({ rel, onSample, pushEvent, core });

  pushEvent('baseline-start');
  log(`  采集运行态基线 ${CONFIG.baselineMs}ms（先别关）...`);
  await sleep(CONFIG.baselineMs);

  await waitEnter(`\n  ▶ 按【回车】后，去手动关闭 ${proc}（叉掉窗口 / 托盘退出 / 任务管理器结束）...`);
  pushEvent('triggered', 'kill-start');
  const startRel = rel();
  log(`  ⏺ 开始轮询进程消失（最多 ${Math.round(60_000 / 1000)}s）...`);

  const gone = await waitProcGone(proc, rel, { timeoutMs: 60_000 });
  const taskEndRel = gone.atMs;
  if (gone.ok) { pushEvent('final', 'proc-gone'); log(`  ✓ 进程已全部退出，关闭耗时 ${Math.round(taskEndRel - startRel)}ms。`); }
  else { pushEvent('timeout', 'still-alive'); warn('  进程 60s 内未完全退出。'); }

  log(`  收尾采集 ${CONFIG.tailMs}ms ...`);
  await sleep(CONFIG.tailMs);
  pushEvent('tail-end');
  h.stop();

  return finalizeSession({
    ctx, jobId: `kill-${proc}`, taskName: `杀进程:${proc}`, trigger: 'probe',
    baselineEndRel: startRel, taskEndRel, outcome: gone.ok ? 'completed' : 'timeout', h,
    scenario, variant, extraDurations: { closeMs: Math.round(taskEndRel - startRel) },
  });
}

// ── orchestrator：场景「冷启动」——先起工具轮询，你再手动启动应用 ──────────
// 起点=回车那刻；分段计时：进程出现 / 端口就绪 / 首屏 load。资源从 0 爬升。
async function collectColdStart({ core, scenario, variant }) {
  const ctx = newSessionCtx();
  const { rel, onSample, pushEvent } = ctx;
  const proc = CONFIG.primaryProc;
  log(`=== 冷启动采集：${proc}  [${scenario}/${variant}] ===`);
  // 冷启动时进程还没起，系统采集器先跑（采到 0/空进程），CDP 稍后由探测触发连。
  const h = await startCollectors({ rel, onSample, pushEvent, core });

  // 提示：必须应用已完全退出，才是“冷”启动
  if (queryPids(proc).length) warn(`  注意：${proc} 当前已在运行。冷启动应先完全退出它再测。`);
  pushEvent('baseline-start');
  await sleep(2000); // 短基线（空闲态）

  await waitEnter(`\n  ▶ 按【回车】后，立刻去启动 ${proc}（双击图标 / 运行启动命令）...`);
  pushEvent('triggered', 'cold-start');
  const startRel = rel();
  log('  ⏺ 开始计时：轮询 进程出现 → 端口就绪 → 首屏 → 可用；任何时候按【回车】即手动确认完成 ...');

  // 手动兜底：任一阶段按【回车】= 以回车时刻为终点、判"完成"。ac 中止未决探针，避免残留轮询挂住进程退出。
  const ac = new AbortController();
  let manualAt = null;
  const rlManual = readline.createInterface({ input: process.stdin });
  const MANUAL = { manual: true };
  const manualStop = new Promise((resolve) => {
    rlManual.once('line', () => { if (manualAt == null) manualAt = rel(); ac.abort(); resolve(MANUAL); });
  });
  const raced = (fn) => Promise.race([fn(ac.signal), manualStop]);

  let procSpawnMs = null, portReadyMs = null, firstPaintMs = null, readyMs = null;
  let taskEndRel = null, outcome = 'completed';

  detect: {
    const appear = await raced((signal) => waitProcAppear(proc, rel, { timeoutMs: 120_000, signal }));
    if (appear === MANUAL) break detect;
    if (!appear.ok) { outcome = 'timeout'; taskEndRel = rel(); pushEvent('timeout', 'no-proc'); warn('  120s 内未探到进程启动。'); break detect; }
    procSpawnMs = Math.round(appear.atMs - startRel);
    pushEvent('proc-appear', procSpawnMs);
    taskEndRel = appear.atMs;
    log(`  ✓ 进程出现 +${procSpawnMs}ms`);

    const port = await raced((signal) => waitCdpReady(CONFIG.cdpUrl, rel, { timeoutMs: 60_000, signal }));
    if (port === MANUAL) break detect;
    if (!port.ok) { log('  （未探到调试端口：冷启动只计到进程出现。竞品/未带调试端口启动属正常。）'); break detect; }
    portReadyMs = Math.round(port.atMs - startRel);
    pushEvent('port-ready', portReadyMs);
    log(`  ✓ 调试端口就绪 +${portReadyMs}ms`);

    const fp = await raced((signal) => waitFirstPage(CONFIG.cdpUrl, rel, { timeoutMs: 60_000, signal }));
    if (fp === MANUAL) break detect;
    if (!fp.ok) break detect;
    firstPaintMs = Math.round(fp.atMs - startRel);
    pushEvent('first-paint', firstPaintMs);
    taskEndRel = fp.atMs;
    log(`  ✓ 首屏页面就绪 +${firstPaintMs}ms（${fp.url}）`);

    // 收紧终点：等关键元素渲染出来（用户可用）；超时回退首屏，或按回车手动确认
    log(`  … 等关键元素就绪（选择器：${CONFIG.readySelector}），或按【回车】手动确认 ...`);
    const ready = await raced((signal) => waitReadyElement(CONFIG.cdpUrl, CONFIG.readySelector, rel, { timeoutMs: CONFIG.readyTimeoutMs, signal }));
    if (ready === MANUAL) break detect;
    if (ready.ok) {
      readyMs = Math.round(ready.atMs - startRel);
      pushEvent('app-ready', readyMs);
      taskEndRel = ready.atMs;
      log(`  ✓ 关键元素就绪（可用）+${readyMs}ms`);
    } else {
      log(`  （${Math.round(CONFIG.readyTimeoutMs / 1000)}s 内未确认关键元素就绪，冷启动终点回退到首屏）`);
    }
  }
  rlManual.close();

  // 手动确认：以回车时刻为终点、判完成，覆盖自动探到的（较早的）终点
  if (manualAt != null) {
    taskEndRel = manualAt;
    pushEvent('final', 'manual-confirm');
    log(`  ✓ 手动确认完成 +${Math.round(manualAt - startRel)}ms`);
  } else if (outcome !== 'timeout') {
    pushEvent('final', 'cold-start-done');
  }
  if (taskEndRel == null) taskEndRel = rel();

  log(`  收尾采集 ${CONFIG.tailMs}ms（看资源爬升）...`);
  await sleep(CONFIG.tailMs);
  pushEvent('tail-end');
  h.stop();

  const extraDurations = {};
  if (procSpawnMs != null) extraDurations.procSpawnMs = procSpawnMs;
  if (portReadyMs != null) extraDurations.portReadyMs = portReadyMs;
  if (firstPaintMs != null) extraDurations.firstPaintMs = firstPaintMs;
  if (readyMs != null) extraDurations.readyMs = readyMs;
  if (manualAt != null) extraDurations.manualMs = Math.round(manualAt - startRel);
  return finalizeSession({
    ctx, jobId: `cold-${proc}`, taskName: `冷启动:${proc}`, trigger: 'probe',
    baselineEndRel: startRel, taskEndRel, outcome, h,
    scenario, variant, extraDurations,
  });
}

// ── orchestrator：场景「热启动」——后台/最小化恢复到窗口激活计时 ──────────
// 主信号：你看到应用切回前台就按【回车】（毫秒级、不依赖 CDP）。
// 辅信号：前台窗口探测（GetForegroundWindow）自动命中也算，取先到者。
async function collectWarmStart({ core, scenario, variant }) {
  const ctx = newSessionCtx();
  const { rel, onSample, pushEvent } = ctx;
  const proc = CONFIG.primaryProc;
  log(`=== 热启动采集：${proc}  [${scenario}/${variant}] ===`);
  if (!queryPids(proc).length) warn(`  注意：${proc} 未在运行。热启动需应用已在后台/最小化。`);
  const h = await startCollectors({ rel, onSample, pushEvent, core });
  const fgProbe = makeForegroundProbe(proc); // 提前启动，付一次性 Add-Type 编译成本

  pushEvent('baseline-start');
  log('  请先把应用最小化 / 切到后台。');
  await sleep(2000);

  await waitEnter(`\n  ▶ 按【回车】后，去激活 ${proc}（点任务栏 / 托盘 / Alt+Tab 切回）...`);
  pushEvent('triggered', 'warm-start');
  const startRel = rel();
  log('  ⏺ 轮询窗口激活；切回前台后可直接按【回车】手动确认 ...');

  // 手动回车 与 前台探测 race；按回车用 AbortController 中止未决轮询，避免残留挂住。
  const ac = new AbortController();
  let manualAt = null;
  const rlManual = readline.createInterface({ input: process.stdin });
  const MANUAL = { manual: true };
  const manualStop = new Promise((resolve) => {
    rlManual.once('line', () => { if (manualAt == null) manualAt = rel(); ac.abort(); resolve(MANUAL); });
  });
  const win = await Promise.race([
    waitForegroundActive(fgProbe, rel, { timeoutMs: 30_000, signal: ac.signal }),
    manualStop,
  ]);
  rlManual.close();

  let taskEndRel, outcome, detail;
  if (win === MANUAL) {
    taskEndRel = manualAt; outcome = 'completed'; detail = 'manual-confirm';
    log(`  ✓ 手动确认激活 +${Math.round(taskEndRel - startRel)}ms。`);
  } else if (win.ok) {
    taskEndRel = win.atMs; outcome = 'completed'; detail = 'window-active';
    log(`  ✓ 窗口激活耗时 ${Math.round(taskEndRel - startRel)}ms。`);
  } else {
    taskEndRel = win.atMs; outcome = 'timeout'; detail = 'no-window';
    warn('  30s 内未探到前台激活（可按回车手动确认）。');
  }
  pushEvent(outcome === 'timeout' ? 'timeout' : 'final', detail);

  log(`  收尾采集 ${CONFIG.tailMs}ms ...`);
  await sleep(CONFIG.tailMs);
  pushEvent('tail-end');
  h.stop();
  fgProbe.stop();

  return finalizeSession({
    ctx, jobId: `warm-${proc}`, taskName: `热启动:${proc}`, trigger: 'probe',
    baselineEndRel: startRel, taskEndRel, outcome, h,
    scenario, variant, extraDurations: { activateMs: Math.round(taskEndRel - startRel) },
  });
}

// ── orchestrator：场景「长监控」——定时长/Ctrl-C 结束，流式落盘抗崩，心跳可见 ──────
async function collectMonitor({ core, scenario, variant, durationMs }) {
  const sc = scenario || '长监控';
  const va = variant || 'default';
  const startEpoch = Date.now();
  const dir = sessionDirFor(startEpoch, sc, va);
  await fsp.mkdir(dir, { recursive: true });
  // 开跑即写 stub meta（outcome:running）：即便第 0 秒崩溃也留下场景/对象身份，供报表兜底恢复。
  await fsp.writeFile(path.join(dir, 'meta.json'), JSON.stringify({
    schemaVersion: 2, jobId: `monitor-${va}`, taskName: `长监控:${va}`, trigger: 'monitor',
    scenario: sc, variant: va, startedAt: startEpoch, outcome: 'running',
    durations: {}, summary: {}, sampleCount: 0,
  }, null, 2)).catch(() => {});
  const ctx = newStreamingSessionCtx(dir, startEpoch);
  const { rel, onSample, pushEvent, tally } = ctx;
  log(`=== 长监控采集：${sc}/${va}  ${durationMs ? '时长 ' + fmtDur(durationMs) : '(Ctrl-C 结束)'} ===`);
  log(`  数据落盘：${dir}`);

  const h = await startCollectors({ rel, onSample, pushEvent, core });

  // ① 基线段
  pushEvent('baseline-start');
  log(`  采集空闲基线 ${CONFIG.baselineMs}ms（先别操作）...`);
  await sleep(CONFIG.baselineMs);
  const baselineEndRel = rel();

  // ② 进入监控
  pushEvent('monitor-start');
  log('  ⏺ 进入长监控。Ctrl-C 可随时优雅结束（再按一次强退）。');

  let stop = false, sigintCount = 0;
  const onSigint = () => {
    if (++sigintCount === 1) { console.log(); log('收到 Ctrl-C，正在优雅收尾 ...'); stop = true; }
    else { warn('强制退出。'); process.exit(1); }
  };
  process.on('SIGINT', onSigint);

  const startMon = nowMs();
  const deadline = durationMs ? startMon + durationMs : Infinity;
  let lastHb = startMon, lastPm = startMon;
  while (!stop && nowMs() < deadline) {
    await sleep(500);
    const now = nowMs();
    if (now - lastHb >= CONFIG.heartbeatMs) { lastHb = now; log('监控中', heartbeatLine(tally, now - startMon)); }
    if (now - lastPm >= CONFIG.partialMetaMs) { lastPm = now; await writePartialMeta(dir, ctx, sc, va, baselineEndRel); }
  }
  process.removeListener('SIGINT', onSigint);
  const taskEndRel = rel();
  pushEvent('monitor-stop', stop ? 'sigint' : 'duration');

  // ③ 收尾
  log(`  收尾采集 ${CONFIG.tailMs}ms ...`);
  await sleep(CONFIG.tailMs);
  pushEvent('tail-end');
  h.stop();
  await ctx.close(); // flush 两个写流

  // ④ 回读算精确 summary（内存恒定期结束，仅此刻一次性装数组）
  log('  回读样本算精确摘要 ...');
  const samples = await readSamplesFromDisk(dir);
  const meta = buildMeta({
    jobId: `monitor-${va}`, taskName: `长监控:${va}`, trigger: 'monitor', startEpoch,
    baselineEndRel, taskEndRel, outcome: 'completed',
    ttftMs: h.stepInfo.ttftMs, coreDurationMs: h.stepInfo.coreDurationMs,
    samples, steps: h.stepInfo.steps,
    caps: { cdp: h.cdp.available, system: h.sys.available, gpu: h.sys.gpuAvailable },
    scenario: sc, variant: va,
  });
  meta.summary.memTrendMB = memTrend(samples, baselineEndRel, taskEndRel);
  await fsp.writeFile(path.join(dir, 'meta.json'), JSON.stringify(meta, null, 2));
  meta._dir = dir;
  const trend = meta.summary.memTrendMB;
  log(`  完成：时长=${fmtDur(meta.durations.totalMs)} CPU峰=${meta.summary.cpu.peak}% 内存峰=${meta.summary.mem.peak}MB `
    + `趋势=${trend == null ? 'NA' : (trend > 0 ? '+' : '') + trend + 'MB'} FPS均=${meta.summary.fps.avg} 样本=${meta.sampleCount}`);
  return meta;
}

// 统一收尾：聚合 → 落盘 → 日志。自动/手动/场景共用。
async function finalizeSession({ ctx, jobId, taskName, trigger, baselineEndRel, taskEndRel, outcome, h, scenario, variant, extraDurations }) {
  const meta = buildMeta({
    jobId, taskName, trigger, startEpoch: ctx.startEpoch,
    baselineEndRel, taskEndRel, outcome,
    ttftMs: h.stepInfo.ttftMs, coreDurationMs: h.stepInfo.coreDurationMs,
    samples: ctx.samples, steps: h.stepInfo.steps,
    caps: { cdp: h.cdp.available, system: h.sys.available, gpu: h.sys.gpuAvailable },
    scenario, variant, extraDurations,
  });
  await writeSession(meta, ctx.samples, ctx.events);
  const extra = extraDurations && Object.keys(extraDurations).length
    ? ' ' + Object.entries(extraDurations).map(([k, v]) => `${k}=${v}ms`).join(' ') : '';
  log(`  完成：[${meta.scenario}/${meta.variant}] outcome=${outcome} 总耗时=${meta.durations.totalMs}ms CPU峰=${meta.summary.cpu.peak}% 内存增量=${meta.summary.mem.delta}MB FPS均=${meta.summary.fps.avg}${extra}`);
  return meta;
}

// ── 聚合：samples → summary（纯逻辑）───────────────────────────────────
// baseline 段（触发前）用于算净增量：delta = 任务活跃段峰值 − 基线均值。
function buildMeta({ jobId, taskName, trigger, startEpoch, baselineEndRel, taskEndRel, outcome, ttftMs, coreDurationMs, samples, steps, caps, scenario, variant, extraDurations }) {
  const pick = (metric) => samples.filter((s) => s.metric === metric);
  const inActive = (s) => s.t >= baselineEndRel && s.t <= taskEndRel + CONFIG.tailMs;
  const inBaseline = (s) => s.t < baselineEndRel;
  const seriesActive = (metric) => pick(metric).filter(inActive).map((s) => s.value);
  const baselineAvg = (metric) => stats(pick(metric).filter(inBaseline).map((s) => s.value)).avg;

  const cpu = stats(seriesActive('cpuPct'));
  const mem = stats(seriesActive('memMB'));
  const gpu = stats(seriesActive('gpuPct'));
  const fps = stats(seriesActive('fps'));
  const wsRtt = stats(seriesActive('netRttMs'));
  const ping = stats(seriesActive('pingMs'));
  const cpuBase = baselineAvg('cpuPct');
  const memBase = baselineAvg('memMB');

  const delta = (peak, base) => (peak != null && base != null) ? +(peak - base).toFixed(1) : null;

  return {
    schemaVersion: 2,
    jobId, taskName: taskName || jobId, trigger,
    scenario: scenario || '对话',       // 场景维度：对话/切换对话/杀进程/冷启动/热启动
    variant: variant || 'default',      // 对象维度：版本标签或竞品名
    startedAt: startEpoch,
    endedAt: startEpoch + Math.round(taskEndRel),
    outcome,
    capabilities: caps,
    durations: {
      totalMs: Math.round(taskEndRel - baselineEndRel),
      ttftMs: ttftMs ?? null,
      coreDurationMs: coreDurationMs ?? null,
      ...(extraDurations || {}),        // 场景特有耗时：如 冷启动的 procSpawnMs/portReadyMs/firstPaintMs
    },
    summary: {
      cpu: { avg: cpu.avg, peak: cpu.peak, baseline: cpuBase, delta: delta(cpu.peak, cpuBase) },
      gpu: caps.gpu ? { avg: gpu.avg, peak: gpu.peak } : { avg: null, peak: null },
      mem: { avg: mem.avg, peak: mem.peak, baseline: memBase, delta: delta(mem.peak, memBase) },
      fps: caps.cdp ? { avg: fps.avg, min: fps.min, p5: fps.p5 } : { avg: null, min: null, p5: null },
      net: { ttftMs: ttftMs ?? null, wsRttAvg: wsRtt.avg, pingAvg: ping.avg },
    },
    steps,
    sampleCount: samples.length,
  };
}

// ── 落盘：session 目录（meta.json + samples.ndjson + events.ndjson）─────
// session 目录命名：<yyyyMMdd-HHmmss>-<安全场景>-<安全对象>
function sessionDirFor(startEpoch, scenario, variant) {
  const ts = new Date(startEpoch);
  const stamp = ts.toISOString().replace(/[-:T]/g, '').slice(0, 15).replace(/(\d{8})(\d+)/, '$1-$2');
  const safe = (s) => String(s ?? '').replace(/[^\w.一-龥-]/g, '_').slice(0, 24);
  return path.join(CONFIG.sessionsDir, `${stamp}-${safe(scenario)}-${safe(variant)}`);
}

async function writeSession(meta, samples, events) {
  const dir = sessionDirFor(meta.startedAt, meta.scenario, meta.variant);
  await fsp.mkdir(dir, { recursive: true });
  await fsp.writeFile(path.join(dir, 'meta.json'), JSON.stringify(meta, null, 2));
  await fsp.writeFile(path.join(dir, 'samples.ndjson'), samples.map((s) => JSON.stringify(s)).join('\n') + '\n');
  await fsp.writeFile(path.join(dir, 'events.ndjson'), events.map((e) => JSON.stringify(e)).join('\n') + '\n');
  meta._dir = dir;
  return dir;
}

// ── 报表：读若干 session → 自包含单文件 HTML ────────────────────────────
// 崩溃恢复：meta 缺失或 outcome=running（跑一半崩了）时，用盘上样本现场重建 summary。
// scenario/variant 优先取 stub/部分 meta，缺失再从目录名尽力解析。outcome 标 interrupted。
function recoverMeta(dirName, partial, samples) {
  const p = partial || {};
  let scenario = p.scenario, variant = p.variant;
  if (!scenario || !variant) {
    const m = /\.-(.+)$/.exec(dirName); // 目录名形如 <stamp>.-<场景>-<对象>
    if (m) {
      const rest = m[1], i = rest.indexOf('-');
      if (i >= 0) { scenario = scenario || rest.slice(0, i); variant = variant || rest.slice(i + 1); }
      else scenario = scenario || rest;
    }
  }
  scenario = scenario || '未知'; variant = variant || 'default';
  let taskEndRel = 0;
  for (const s of samples) if (typeof s.t === 'number' && s.t > taskEndRel) taskEndRel = s.t; // 避免 Math.max(...大数组) 溢出
  const baselineEndRel = Math.min(CONFIG.baselineMs, taskEndRel);
  const caps = {
    cdp: samples.some((s) => s.source === 'cdp'),
    system: samples.some((s) => s.source === 'system'),
    gpu: samples.some((s) => s.metric === 'gpuPct'),
  };
  const meta = buildMeta({
    jobId: p.jobId || 'recovered', taskName: p.taskName || `恢复:${variant}`, trigger: p.trigger || 'monitor',
    startEpoch: p.startedAt || 0, baselineEndRel, taskEndRel, outcome: 'interrupted',
    ttftMs: null, coreDurationMs: null, samples, steps: [], caps, scenario, variant,
  });
  meta.summary.memTrendMB = memTrend(samples, baselineEndRel, taskEndRel);
  return meta;
}

async function loadSessions(sessionsDir) {
  let entries = [];
  try { entries = await fsp.readdir(sessionsDir, { withFileTypes: true }); } catch { return []; }
  const out = [];
  for (const e of entries) {
    if (!e.isDirectory()) continue;
    const dir = path.join(sessionsDir, e.name);
    try {
      const samplesRaw = await fsp.readFile(path.join(dir, 'samples.ndjson'), 'utf8').catch(() => '');
      const eventsRaw = await fsp.readFile(path.join(dir, 'events.ndjson'), 'utf8').catch(() => '');
      const samples = samplesRaw.trim().split('\n').filter(Boolean).map((l) => JSON.parse(l));
      const events = eventsRaw.trim().split('\n').filter(Boolean).map((l) => JSON.parse(l));
      let meta = null;
      try { meta = JSON.parse(await fsp.readFile(path.join(dir, 'meta.json'), 'utf8')); } catch { /* meta 缺失，下方兜底 */ }
      // 崩溃恢复：无 meta 或 outcome 仍 running，且有样本 → 现场重建
      if ((!meta || meta.outcome === 'running') && samples.length) meta = recoverMeta(e.name, meta, samples);
      if (!meta) continue; // 既无 meta 又无样本 → 跳过
      out.push({ dirName: e.name, meta, samples, events });
    } catch { /* 跳过损坏 session */ }
  }
  // 按开始时间排序
  out.sort((a, b) => (a.meta.startedAt || 0) - (b.meta.startedAt || 0));
  return out;
}

// LTTB(Largest-Triangle-Three-Buckets)：保峰抽稀，输入按 x 升序，输出长度=threshold，首尾保留。
function lttb(points, threshold) {
  const n = points.length;
  if (threshold >= n || threshold < 3) return points.slice();
  const sampled = [points[0]];
  const bucketSize = (n - 2) / (threshold - 2);
  let a = 0;
  for (let i = 0; i < threshold - 2; i++) {
    // 下一桶的平均点（算三角面积的第三顶点）
    let avgRangeStart = Math.floor((i + 1) * bucketSize) + 1;
    let avgRangeEnd = Math.min(Math.floor((i + 2) * bucketSize) + 1, n);
    const avgLen = avgRangeEnd - avgRangeStart;
    let avgX = 0, avgY = 0;
    if (avgLen > 0) {
      for (let j = avgRangeStart; j < avgRangeEnd; j++) { avgX += points[j].x; avgY += points[j].y; }
      avgX /= avgLen; avgY /= avgLen;
    } else { const p = points[Math.min(avgRangeStart, n - 1)]; avgX = p.x; avgY = p.y; }
    // 当前桶：选与 a、平均点构成最大三角形面积的点
    let rangeOffs = Math.floor(i * bucketSize) + 1;
    const rangeTo = Math.floor((i + 1) * bucketSize) + 1;
    const ax = points[a].x, ay = points[a].y;
    let maxArea = -1, nextA = rangeOffs;
    for (; rangeOffs < rangeTo; rangeOffs++) {
      const area = Math.abs((ax - avgX) * (points[rangeOffs].y - ay) - (ax - points[rangeOffs].x) * (avgY - ay)) * 0.5;
      if (area > maxArea) { maxArea = area; nextA = rangeOffs; }
    }
    sampled.push(points[nextA]);
    a = nextA;
  }
  sampled.push(points[n - 1]);
  return sampled;
}

const REPORT_POINT_BUDGET = 2000; // 报表每条曲线最多点数（LTTB 抽稀目标）

// 展示级抽稀：按 metric 分组，滤 null，超预算才 LTTB，展平回样本形状，整体按 t 升序。
function decimateSessionSamples(samples, budget = REPORT_POINT_BUDGET) {
  const byMetric = new Map();
  for (const s of samples) {
    if (!byMetric.has(s.metric)) byMetric.set(s.metric, []);
    byMetric.get(s.metric).push(s);
  }
  const out = [];
  for (const arr of byMetric.values()) {
    const finite = arr
      .filter((s) => typeof s.value === 'number' && Number.isFinite(s.value))
      .sort((a, b) => a.t - b.t);
    if (finite.length <= budget) { out.push(...finite); continue; }
    const pts = finite.map((s) => ({ x: s.t, y: s.value, s }));
    for (const p of lttb(pts, budget)) out.push(p.s);
  }
  out.sort((a, b) => a.t - b.t);
  return out;
}

async function buildReport(sessionsDir) {
  const sessions = await loadSessions(sessionsDir);
  if (!sessions.length) { warn(`未找到任何 session（${sessionsDir}）。先跑 run 采集。`); return null; }
  // 数据内联进 HTML（自包含、可分享）
  const payload = sessions.map((s) => ({
    dirName: s.dirName, meta: s.meta,
    samples: decimateSessionSamples(s.samples, REPORT_POINT_BUDGET),
    events: s.events,
  }));
  // 图表库优先内联本地 vendor（真·自包含、断网可用、无 CDN 风险）；缺失时回退带 SRI 的 CDN。
  const vendor = await loadVendor();
  const html = renderReportHtml(payload, vendor);
  const outFile = path.join(sessionsDir, `perfdog-report-${Date.now()}.html`);
  await fsp.writeFile(outFile, html);
  log(`报表已生成：${outFile}（含 ${sessions.length} 个 session，图表库=${vendor ? '内联' : 'CDN'}）`);
  return outFile;
}

// 读本地 vendor 的 uPlot JS/CSS 内联进报表；读不到返回 null（回退 CDN）。
async function loadVendor() {
  try {
    const js = await fsp.readFile(path.join(__dirname, 'vendor', 'uplot.js'), 'utf8');
    const css = await fsp.readFile(path.join(__dirname, 'vendor', 'uplot.css'), 'utf8');
    return { js, css };
  } catch { return null; }
}

function renderReportHtml(payload, vendor) {
  const dataJson = JSON.stringify(payload).replace(/</g, '\\u003c');
  // 读纯逻辑源码，剥离 ESM export 行后内联（浏览器端与单测共用同一份实现，DRY）
  let logicSrc = '';
  try { logicSrc = fs.readFileSync(path.join(__dirname, 'report-logic.mjs'), 'utf8').replace(/^export\s*\{[^}]*\};?\s*$/m, ''); } catch { logicSrc = ''; }
  // 内联优先：把 uPlot JS/CSS 直接嵌入，报表单文件自包含。回退用固定版本 CDN + SRI 完整性校验。
  const head = vendor
    ? `<style>${vendor.css}</style>\n<script>${vendor.js.replace(/<\/script>/gi, '<\\/script>')}</script>`
    : `<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uplot@1.6.30/dist/uPlot.min.css"`
      + ` integrity="sha384-IfV0B7MIOYuO95kO9G5ySKPz/85zqFNOAs8iy4tkK5zd9izhJAB8b7lHrwYqqmYE" crossorigin="anonymous"/>\n`
      + `<script src="https://cdn.jsdelivr.net/npm/uplot@1.6.30/dist/uPlot.iife.min.js"`
      + ` integrity="sha384-1NEYi76CBpge3gahk4+X4M4JzdOV3WYq84RnByqYdAd5SdvJBTNCPFh/nsoHfN6i" crossorigin="anonymous"></script>`;
  return `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>nami-perfdog 性能报表</title>
${head}
<style>${REPORT_CSS}</style>
</head><body>
<header class="hero">
  <h1>nami-perfdog <span>性能报表</span></h1>
  <p>纳米 Work 客户端 · 定时任务全流程性能采集 · 生成于 <span id="genat"></span></p>
</header>
<main>
  <section id="tldr"><h2>📋 一句话总结</h2><div id="tldr-box"></div></section>
  <section id="kpi"><h2>核心指标速览</h2><div id="kpi-box"></div></section>
  <section id="scenes"><h2>逐场景对比</h2><div id="scene-box"></div></section>
  <section id="glossary"><h2>📖 指标怎么看（大白话）</h2><div id="glossary-box"></div></section>
</main>
<footer>nami-perfdog · 单文件报表 · 数据内联可分享 · FPS/CPU/GPU/内存/网络延迟</footer>
<script>const PERFDOG_DATA=${dataJson};</script>
<script>${logicSrc}</script>
<script>${REPORT_JS}</script>
</body></html>`;
}

const REPORT_CSS = `
:root{--bg:#0f1420;--card:#1a2233;--card2:#202a3f;--border:#2a3652;--text:#dce3f0;--dim:#96a2bd;
--c-cpu:#5b9dff;--c-gpu:#f5a742;--c-mem:#38d3b0;--c-fps:#c78bff;--c-ws:#ff7a9c;--c-ping:#7de0d0;--warn:#e07a7a;}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);
font-family:-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;line-height:1.6}
.hero{padding:28px 36px;background:radial-gradient(1000px 300px at 10% -20%,rgba(91,157,255,.18),transparent 60%),#161c2b;border-bottom:1px solid var(--border)}
.hero h1{margin:0;font-size:26px}.hero h1 span{color:#5b9dff}.hero p{margin:6px 0 0;color:var(--dim);font-size:13px}
main{max-width:1200px;margin:0 auto;padding:28px 24px 80px}
section{margin:34px 0}h2{font-size:19px;border-left:3px solid #5b9dff;padding-left:10px}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden;font-size:13.5px}
th,td{padding:9px 12px;border-bottom:1px solid var(--border);text-align:right}
th:first-child,td:first-child{text-align:left}th{background:var(--card2);cursor:pointer;user-select:none}
tr:last-child td{border-bottom:none}td.best{color:#38d3b0;font-weight:600}td.worst{color:#ff7a9c;font-weight:600}
.na{color:var(--dim);font-style:italic}
.badge{display:inline-block;padding:1px 8px;border-radius:999px;font-size:11px;border:1px solid var(--border)}
.badge.completed{color:#38d3b0}.badge.failed,.badge.timeout{color:#e07a7a}.badge.interrupted{color:#e0c56e}
.picker{margin:14px 0}select{background:var(--card);color:var(--text);border:1px solid var(--border);border-radius:8px;padding:6px 10px;font-size:14px}
.chart-wrap{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:12px 8px 4px;margin:14px 0}
.chart-title{font-size:13px;color:var(--dim);padding:0 8px 4px}
.bars{display:grid;gap:10px;margin-top:14px}
.bar-row{display:grid;grid-template-columns:160px 1fr;gap:10px;align-items:center;font-size:13px}
.bar-track{background:var(--card2);border-radius:6px;overflow:hidden;height:22px;position:relative}
.bar-fill{height:100%;border-radius:6px}
.legend{display:flex;gap:16px;flex-wrap:wrap;font-size:12px;color:var(--dim);padding:4px 8px 10px}
.legend i{display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:5px;vertical-align:-1px}
.caps{font-size:11px;color:var(--warn);margin-top:4px}
.scenario-block{margin:0 0 22px}.scenario-name{font-size:14px;font-weight:600;margin:0 0 8px;color:var(--text)}
.dim{color:var(--dim);font-weight:400;font-size:12px}
.tag{display:inline-block;font-size:10px;padding:0 6px;border-radius:4px;background:var(--card2);color:var(--warn);border:1px solid var(--border)}
#tldr-box{background:var(--card);border:1px solid var(--border);border-left:3px solid var(--c-mem);border-radius:12px;padding:16px 20px;font-size:14.5px;line-height:1.9}
#tldr-box .line{margin:2px 0}#tldr-box .hi{color:var(--c-fps);font-weight:600}#tldr-box .good{color:#38d3b0;font-weight:600}#tldr-box .bad{color:#ff7a9c;font-weight:600}#tldr-box .mid{color:#f5a742;font-weight:600}
.dot{font-size:10px;vertical-align:1px}
td .dot{margin-right:2px}
.gloss{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:12px}
.gloss-item{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:12px 14px}
.gloss-item h4{margin:0 0 4px;font-size:14px;color:var(--c-cpu)}
.gloss-item p{margin:0;font-size:12.5px;color:var(--dim);line-height:1.7}
.gloss-item .rule{color:#38d3b0}
#kpi-box{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}
.kpi{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:14px 16px}
.kpi .k-label{font-size:12px;color:var(--dim)}
.kpi .k-val{font-size:23px;font-weight:700;margin-top:4px}
.kpi .k-scene{font-size:11px;color:var(--dim);margin-top:2px}
#tldr-box .verdict{font-size:15px;font-weight:600;margin:6px 0;padding:9px 13px;border-radius:8px;background:var(--card2)}
#tldr-box .verdict.good{color:#38d3b0}#tldr-box .verdict.bad{color:#ff7a9c}#tldr-box .verdict.mid{color:#f5a742}
.kpi .k-row{display:flex;justify-content:space-between;align-items:baseline;font-size:13px;margin-top:3px}
.kpi .k-tag{color:var(--dim);font-size:11px}
.kpi .k-num{font-weight:600}
.kpi .k-delta{font-weight:700;margin-top:6px;border-top:1px solid var(--border);padding-top:5px}
.scene-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px 18px;margin:16px 0}
.scene-card h3{margin:0 0 12px;font-size:16px;border-left:3px solid var(--c-mem);padding-left:9px}
.scene-card .scene-charts{margin-top:12px}
table.cmp2{margin:0}
table.cmp2 td.win{color:#38d3b0;font-weight:700}
table.cmp2 .winner{color:#38d3b0;font-weight:600}
table.cmp2 .tie{color:var(--dim)}
footer{color:var(--dim);font-size:12px;text-align:center;padding:20px;border-top:1px solid var(--border)}
`;

const REPORT_JS = String.raw`
(function(){
  var D = PERFDOG_DATA;
  document.getElementById('genat').textContent = new Date().toLocaleString('zh-CN');

  // ── 指标好坏阈值（绝对基准，不依赖对比）───────────────────────
  // 每项 [好上限, 一般上限]：lowGood=true(越低越好) → <好=good, <一般=mid, 否则 bad；
  // lowGood=false(越高越好，如 FPS) → 反向。改这张表即可调判定标准。
  var THRESH = {
    totalMs:   {t:[null,null], lowGood:true},   // 对话总耗时看内容长短，不做绝对判定
    coldTotal: {t:[5000,10000], lowGood:true},  // 冷启动到"可用"（关键元素就绪）
    activateMs:{t:[500,1500],  lowGood:true},   // 热启动激活
    closeMs:   {t:[1000,3000], lowGood:true},   // 关闭耗时
    ttftMs:    {t:[1500,3000], lowGood:true},   // 首 token
    cpuPeak:   {t:[50,80],     lowGood:true},
    cpuAvg:    {t:[25,50],     lowGood:true},
    memDelta:  {t:[100,400],   lowGood:true},   // 内存增量 MB
    memPeak:   {t:[null,null], lowGood:true},   // 峰值绝对量因机而异，不硬判
    gpuPeak:   {t:[50,80],     lowGood:true},
    fpsAvg:    {t:[55,30],     lowGood:false},  // FPS 越高越好：>=55 好，>=30 一般，否则差
    wsRtt:     {t:[100,300],   lowGood:true},
    ping:      {t:[50,150],    lowGood:true}
  };
  // 返回 'good'|'mid'|'bad'|'' （无阈值/无值返回 ''）
  function rate(key, v){
    var cfg=THRESH[key]; if(!cfg||typeof v!=='number') return '';
    var a=cfg.t[0], b=cfg.t[1]; if(a==null||b==null) return '';
    if(cfg.lowGood) return v<a?'good':(v<=b?'mid':'bad');
    return v>=a?'good':(v>=b?'mid':'bad');
  }
  var RATE_CN={good:'好',mid:'一般',bad:'差'};
  var RATE_DOT={good:'🟢',mid:'🟡',bad:'🔴'};

  // ── 指标说明（固定大白话）─────────────────────────────────────
  var GLOSSARY=[
    {name:'总耗时',desc:'这次任务从开始到结束花的时间。',rule:'越短越好；对话看内容长短，启动类越快越流畅。'},
    {name:'冷启动',desc:'从应用没开到首屏能用的时间（进程拉起+端口就绪+首屏渲染）。',rule:'越短越好；秒级正常，超过 5 秒偏慢。'},
    {name:'激活(热启动)',desc:'应用在后台，点回来到窗口可用的时间。',rule:'越短越好；通常应在 1 秒内。'},
    {name:'关闭',desc:'点关闭到进程完全退出的时间。',rule:'越短越好；太久说明退出时还在干活/没释放干净。'},
    {name:'首token',desc:'发消息后 AI 吐出第一个字的等待时间。',rule:'越短体感越快；1-2 秒正常，超过 3 秒会觉得卡。'},
    {name:'CPU峰值/均值',desc:'任务期间占用处理器的最高/平均百分比（已按核数归一）。',rule:'越低越好；峰值偶尔高正常，均值持续高说明费 CPU。'},
    {name:'内存增量',desc:'任务期间比空闲时多吃的内存。',rule:'越低越好；几十 MB 正常，几百 MB 偏高，只涨不落可能有泄漏。'},
    {name:'内存峰值',desc:'任务期间进程占用内存的最高值。',rule:'看绝对量；同场景两版本比，低的更省内存。'},
    {name:'GPU峰值',desc:'任务期间显卡占用最高百分比。',rule:'越低越好；渲染/动画多时会高。竞品或无独显时可能取不到。'},
    {name:'平均FPS',desc:'每秒画面刷新次数，反映流不流畅。',rule:'越高越好；60 满帧最顺，低于 30 会明显卡顿。'},
    {name:'WS延迟',desc:'前端和服务器之间一次请求往返的耗时。',rule:'越低越好；反映网络传输快慢。'},
    {name:'ping',desc:'到网关服务器的网络基线延迟（环境好坏）。',rule:'越低越好；用来判断是不是网络环境背锅。'}
  ];
  function renderGlossary(){
    document.getElementById('glossary-box').innerHTML='<div class="gloss">'+GLOSSARY.map(function(g){
      return '<div class="gloss-item"><h4>'+g.name+'</h4><p>'+g.desc+'<br><span class="rule">▸ '+g.rule+'</span></p></div>';
    }).join('')+'</div>';
  }

  /*__REPORT_RENDER_BODY__*/
  function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  var RATE_DOT2={good:'🟢',mid:'🟡',bad:'🔴'};
  var dot=function(r){return r?'<span class="dot '+r+'">'+RATE_DOT2[r]+'</span> ':'';};

  var GROUPS=groupByScenario(D);

  // ── A. 一句话总结 ─────────────────────────────────────────────
  function renderTldr(){
    var box=document.getElementById('tldr-box');
    var objs={}; D.forEach(function(s){objs[s.meta.variant||'default']=1;});
    var objList=Object.keys(objs);
    var lines=[];
    lines.push('<div class="line">本报告共 <span class="hi">'+D.length+'</span> 次采集，覆盖 <span class="hi">'+GROUPS.length+'</span> 个场景、<span class="hi">'+objList.length+'</span> 个对象（'+objList.map(esc).join('、')+'）。</div>');
    // 单段全局结论（新版 vs 旧版整体好坏 + 最大改善/退步，方向从数据现算）
    var vd=buildVerdict(GROUPS);
    if(vd){ var cls=vd.tone==='worse'?'bad':(vd.tone==='mixed'?'mid':'good'); lines.push('<div class="line verdict '+cls+'">'+esc(vd.text)+'</div>'); }
    else lines.push('<div class="line" style="color:var(--dim)">暂无可对比的新旧版本（需同场景恰好 2 个版本）。</div>');
    // 内存趋势泄漏提示（长监控专属）
    D.forEach(function(s){
      var m=s.meta, tr=m.summary&&m.summary.memTrendMB;
      if(typeof tr!=='number') return;
      var tag = tr>100 ? '<span class="bad">🔴 内存持续上涨</span>' : (tr>30 ? '<span class="mid">🟡 内存缓升</span>' : '<span class="good">🟢 内存平稳</span>');
      lines.push('<div class="line">【'+esc(m.scenario||'')+' / '+esc(m.variant||'default')+'】'+tag+' 首尾差 '+(tr>0?'+':'')+tr+'MB'+(tr>100?'，疑似泄漏，建议下钻内存曲线':'')+'。</div>');
    });
    box.innerHTML=lines.join('');
  }

  // ── B. 核心指标速览（2对象出 新值/旧值/差值三行；单对象出单值）──
  function renderKpi(){
    var box=document.getElementById('kpi-box');
    var kpis=pickKpis(GROUPS);
    if(!kpis.length){ box.innerHTML='<p class="dim">暂无可展示的核心指标。</p>'; return; }
    box.innerHTML=kpis.map(function(k){
      if(k.single){
        return '<div class="kpi"><div class="k-label">'+dot(k.rate)+esc(k.label)+'</div>'
          +'<div class="k-val">'+fmtVal(k.value,k.unit)+'</div>'
          +'<div class="k-scene">'+esc(k.scenario)+'</div></div>';
      }
      return '<div class="kpi"><div class="k-scene">'+esc(k.scenario)+' · '+esc(k.label)+'</div>'
        +'<div class="k-row"><span class="k-tag">新 '+esc(k.aVer)+'</span><span class="k-num">'+fmtVal(k.aVal,k.unit)+'</span></div>'
        +'<div class="k-row"><span class="k-tag">旧 '+esc(k.bVer)+'</span><span class="k-num">'+fmtVal(k.bVal,k.unit)+'</span></div>'
        +'<div class="k-row k-delta">'+dot(k.rate)+'差值 '+esc(k.deltaText)+'</div></div>';
    }).join('');
  }

  // ── C. 逐场景卡片（2对象双列 / ≥3多列 / 1单列）+ 曲线下钻 ──────
  var METRICS=[
    {metric:'cpuPct',label:'CPU %'},{metric:'gpuPct',label:'GPU %'},{metric:'memMB',label:'内存 MB'},
    {metric:'fps',label:'FPS'},{metric:'netRttMs',label:'WS/API 延迟 ms'},{metric:'pingMs',label:'环境 ping ms'}
  ];
  var SERIES_COLORS=['#5b9dff','#f5a742','#38d3b0','#c78bff','#ff7a9c','#7de0d0','#e0c56e','#8fd66a'];
  var allCharts=[];

  // 该维度在这组对象里有任一有数才显示该行
  function dimHasData(objects,dim){ return objects.some(function(o){var v=dim.get(o.meta);return typeof v==='number'&&isFinite(v);}); }

  function renderTwoCol(g){
    var A=g.objects[0], B=g.objects[1];
    var rows=DIMENSIONS.filter(function(d){return dimHasData(g.objects,d);}).map(function(dim){
      var r=cmp2(A.meta,B.meta,dim);
      var aCls=r.winner==='A'?' class="win"':'', bCls=r.winner==='B'?' class="win"':'';
      var winCell;
      if(r.winner==='A') winCell='<span class="winner">'+esc(A.variant)+'</span> '+winnerText(dim,r);
      else if(r.winner==='B') winCell='<span class="winner">'+esc(B.variant)+'</span> '+winnerText(dim,r);
      else if(r.winner==='tie') winCell='<span class="tie">持平</span>';
      else winCell='<span class="na">—</span>';
      return '<tr><td>'+esc(dim.label)+'</td><td'+aCls+'>'+fmtVal(r.aVal,dim.unit)+'</td><td'+bCls+'>'+fmtVal(r.bVal,dim.unit)
        +'</td><td>'+(r.ratio==null?'<span class="na">—</span>':r.ratio)+'</td><td>'+winCell+'</td></tr>';
    }).join('');
    return '<table class="cmp2"><thead><tr><th>维度</th><th>'+esc(A.variant)+'</th><th>'+esc(B.variant)
      +'</th><th>'+esc(A.variant)+'/'+esc(B.variant)+'</th><th>胜者</th></tr></thead><tbody>'+rows+'</tbody></table>';
  }

  function renderMultiCol(g){
    var objs=g.objects;
    var rows=DIMENSIONS.filter(function(d){return dimHasData(objs,d)&&d.lowGood!=null;}).map(function(dim){
      var vals=objs.map(function(o){return dim.get(o.meta);});
      var nums=vals.filter(function(v){return typeof v==='number'&&isFinite(v);});
      var best=nums.length?(dim.lowGood?Math.min.apply(null,nums):Math.max.apply(null,nums)):null;
      var tds=vals.map(function(v){
        var isBest=(typeof v==='number'&&v===best&&nums.length>1);
        return '<td'+(isBest?' class="win"':'')+'>'+fmtVal(v,dim.unit)+'</td>';
      }).join('');
      return '<tr><td>'+esc(dim.label)+'</td>'+tds+'</tr>';
    }).join('');
    var head='<tr><th>维度</th>'+objs.map(function(o){return '<th>'+esc(o.variant)+'</th>';}).join('')+'</tr>';
    return '<table class="cmp2"><thead>'+head+'</thead><tbody>'+rows+'</tbody></table>';
  }

  function renderOneCol(g){
    var o=g.objects[0];
    var rows=DIMENSIONS.filter(function(d){return dimHasData(g.objects,d);}).map(function(dim){
      var v=dim.get(o.meta);
      var r=rateOf(dim.key,v);
      return '<tr><td>'+esc(dim.label)+'</td><td>'+dot(r)+fmtVal(v,dim.unit)+'</td></tr>';
    }).join('');
    return '<table class="cmp2"><thead><tr><th>维度</th><th>'+esc(o.variant)+'</th></tr></thead><tbody>'+rows+'</tbody></table>';
  }

  // 场景卡底部曲线：各对象叠加（复用原 renderTimelines 的 x 对齐 + uPlot 逻辑）
  function renderSceneCharts(g, mount){
    var colorOf={}; g.objects.forEach(function(o,i){colorOf[o.variant]=SERIES_COLORS[i%SERIES_COLORS.length];});
    var legend=document.createElement('div');legend.className='legend';
    legend.innerHTML=g.objects.map(function(o){return '<span><i style="background:'+colorOf[o.variant]+'"></i>'+esc(o.variant)+'</span>';}).join('');
    mount.appendChild(legend);
    METRICS.forEach(function(mc){
      var seriesList=g.objects.map(function(o){
        var pts=(o.samples||[]).filter(function(x){return x.metric===mc.metric;});
        return {variant:o.variant, pts:pts, color:colorOf[o.variant]};
      }).filter(function(x){return x.pts.length;});
      if(!seriesList.length)return;
      var xset={};
      seriesList.forEach(function(sl){sl.pts.forEach(function(p){xset[(p.t/1000).toFixed(1)]=1;});});
      var xs=Object.keys(xset).map(parseFloat).sort(function(a,b){return a-b;});
      var data=[xs];
      seriesList.forEach(function(sl){
        var map={}; sl.pts.forEach(function(p){map[(p.t/1000).toFixed(1)]=p.value;});
        data.push(xs.map(function(x){var k=x.toFixed(1);return k in map?map[k]:null;}));
      });
      var wrap=document.createElement('div');wrap.className='chart-wrap';
      var ct=document.createElement('div');ct.className='chart-title';ct.textContent=mc.label;
      wrap.appendChild(ct);mount.appendChild(wrap);
      var series=[{label:'t(s)'}].concat(seriesList.map(function(sl){return {label:sl.variant,stroke:sl.color,width:1.6,spanGaps:true};}));
      var opts={width:Math.min(1080,mount.clientWidth-24),height:180,scales:{x:{time:false}},
        axes:[{stroke:'#96a2bd',grid:{stroke:'#2a3652'}},{stroke:'#96a2bd',grid:{stroke:'#2a3652'}}],
        series:series,legend:{show:true}};
      allCharts.push(new uPlot(opts,data,wrap));
    });
  }

  function renderScenes(){
    var box=document.getElementById('scene-box');box.innerHTML='';
    if(!GROUPS.length){ box.innerHTML='<p class="dim">无场景数据。</p>'; return; }
    GROUPS.forEach(function(g){
      var card=document.createElement('div');card.className='scene-card';
      var n=g.objects.length;
      var sub=n===2?'2 个对象对比':(n>2?n+' 个对象':'单对象');
      card.innerHTML='<h3>'+esc(g.scenario)+' <span class="dim" style="font-size:12px;font-weight:400">'+sub+'</span></h3>';
      var tblHtml = n===2?renderTwoCol(g):(n>2?renderMultiCol(g):renderOneCol(g));
      var tbl=document.createElement('div');tbl.innerHTML=tblHtml;card.appendChild(tbl.firstChild);
      var charts=document.createElement('div');charts.className='scene-charts';card.appendChild(charts);
      box.appendChild(card);
      renderSceneCharts(g, charts); // 挂载后再画（需 clientWidth）
    });
  }

  renderTldr(); renderKpi(); renderScenes(); renderGlossary();
})();
`;

// ── 任务发现：cron.list → 供选择 ────────────────────────────────────────
async function fetchTasks(core) {
  try {
    const r = await core.call('cron.list', {});
    // 兼容不同返回结构：{jobs:[...]} 或 {items:[...]} 或直接数组
    const jobs = r.jobs || r.items || r.list || (Array.isArray(r) ? r : []);
    return jobs.map((j) => ({ id: j.id || j.jobId, name: j.name || j.title || j.id }));
  } catch (e) {
    warn(`cron.list 失败：${e.message}`);
    return [];
  }
}

// 时长解析：'12h'|'30m'|'90s'|'500ms'|'1000'(无单位=ms) → 毫秒；非法/空/true → null
function parseDuration(v) {
  if (v == null || v === true) return null;
  const m = /^(\d+(?:\.\d+)?)\s*(ms|s|m|h)?$/i.exec(String(v).trim());
  if (!m) return null;
  const mult = { ms: 1, s: 1000, m: 60_000, h: 3_600_000 }[(m[2] || 'ms').toLowerCase()];
  return Math.round(parseFloat(m[1]) * mult);
}

// ── CLI 参数解析 ────────────────────────────────────────────────────────
function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) { const k = a.slice(2); const v = argv[i + 1]?.startsWith('--') ? true : argv[++i]; args[k] = v ?? true; }
    else args._.push(a);
  }
  return args;
}

async function connectCore() {
  const core = new CoreClient(CONFIG.coreWs);
  await core.connect();
  return core;
}

// 非致命连 core：连不上返回 null（竞品对象 / core 没起时不阻断采集）。
async function tryConnectCore() {
  try { return await connectCore(); }
  catch (e) { warn(`nmcore 未连上（${CONFIG.coreWs}）：${e.message}；任务/网络指标不可用，仅采系统级+CDP。`); return null; }
}

// 应用 run 级选项：--proc 覆盖被测进程名（竞品用），影响系统级进程树聚合与场景探测。
function applyRunOpts(args) {
  if (typeof args.proc === 'string' && args.proc.trim()) {
    // 竞品：只测这一个进程名（不再默认带 nmcore）。多个用逗号分隔。
    CONFIG.procNames = args.proc.split(',').map((s) => s.trim()).filter(Boolean);
    CONFIG.primaryProc = CONFIG.procNames[0];
  } else {
    CONFIG.primaryProc = 'Namiwork.exe';
  }
  // 冷启动"就绪"判据可覆盖：--ready-selector <css>
  if (typeof args['ready-selector'] === 'string' && args['ready-selector'].trim()) {
    CONFIG.readySelector = args['ready-selector'].trim();
  }
}

async function cmdListTasks() {
  const core = await connectCore();
  const tasks = await fetchTasks(core);
  core.close();
  if (!tasks.length) {
    log('未发现自动化任务（cron.list 返回 0 个）。');
    log('  → 请先在纳米 Work 客户端「自动化」里创建至少一个定时任务（如"每日行业动态生成"），');
    log('    或用 --trigger ui 手动触发一次已有对话来采集。');
    return;
  }
  log(`发现 ${tasks.length} 个自动化任务：`);
  tasks.forEach((t) => console.log(`  ${t.id}\t${t.name}`));
}

async function cmdRun(args) {
  applyRunOpts(args);
  const scenario = typeof args.scenario === 'string' ? args.scenario : (args.manual ? '对话' : null);
  const variant = typeof args.variant === 'string' ? args.variant : 'default';

  // 长监控：定时长/Ctrl-C 结束，流式落盘。放在 manual 分支之前拦截。
  if (scenario === '长监控' || args.monitor) {
    let durationMs = null;
    if (args.duration != null && args.duration !== true) {
      durationMs = parseDuration(args.duration);
      if (durationMs == null) { warn(`--duration 无法解析：${args.duration}（例：12h / 30m / 90s / 60000）`); return; }
    }
    const core = await tryConnectCore();
    try { await collectMonitor({ core, scenario: '长监控', variant, durationMs }); }
    catch (e) { warn(`长监控采集异常：${e.message}`); }
    if (core) core.close();
    const out = await buildReport(CONFIG.sessionsDir);
    if (out) log(`可用浏览器打开报表：${out}`);
    return;
  }

  // 场景分派：杀进程/冷启动/热启动走探测式记录器（不连 core 也能跑）。
  const probeScenarios = { '杀进程': collectKill, '冷启动': collectColdStart, '热启动': collectWarmStart };
  if (scenario && probeScenarios[scenario]) {
    const core = await tryConnectCore(); // 冷启动会在进程起来后重连；这里先尽力连
    try {
      await probeScenarios[scenario]({ core, variant, scenario });
    } catch (e) {
      warn(`${scenario} 采集异常：${e.message}`);
    }
    if (core) core.close();
    const out = await buildReport(CONFIG.sessionsDir);
    if (out) log(`可用浏览器打开报表：${out}`);
    return;
  }

  // 手动模式（对话/切换对话/首次安装等”框窗口”场景）：不依赖 cron 任务，两次回车框定起止。
  if (args.manual || (scenario && scenario !== '自动化任务')) {
    const core = await tryConnectCore();
    const name = typeof args.manual === 'string' ? args.manual
      : (typeof args.name === 'string' ? args.name : (scenario || null));
    // 按场景定制提示语（首次安装换成安装措辞；其余用 collectManual 默认对话措辞）
    const promptsByScenario = {
      '首次安装': {
        start: '\n  ▶ 基线已采完。按【回车】后立刻去双击安装包开始安装...',
        startedHint: '  ⏺ 开始计时。现在去完成安装（下一步/同意/安装）。装完回到这里。',
        stop: '  ⏹ 安装完成后（看到”完成/Finish”界面），按【回车】结束采集...',
      },
    };
    try {
      await collectManual({ core, taskName: name, scenario: scenario || '对话', variant, prompts: promptsByScenario[scenario] });
    } catch (e) {
      warn(`手动采集异常：${e.message}`);
    }
    if (core) core.close();
    const out = await buildReport(CONFIG.sessionsDir);
    if (out) log(`可用浏览器打开报表：${out}`);
    return;
  }

  // 自动模式：cron 定时任务（--task / --match），走 RPC 强触发。
  const core = await connectCore();
  const tasks = await fetchTasks(core);
  let targets = [];
  if (args.task) {
    const ids = String(args.task).split(',').map((s) => s.trim()).filter(Boolean);
    targets = ids.map((id) => ({ id, name: tasks.find((t) => t.id === id)?.name || id }));
  } else if (args.match) {
    const kw = String(args.match);
    targets = tasks.filter((t) => (t.name || '').includes(kw) || (t.id || '').includes(kw));
  } else {
    core.close();
    warn('请指定采集方式之一：');
    warn('  --manual [名称]                 手动框窗口（对话/切换对话）');
    warn('  --scenario 冷启动|热启动|杀进程   探测式场景（配 --variant 标对象）');
    warn('  --task <id> / --match <关键词>    cron 定时任务');
    return;
  }
  if (!targets.length) { core.close(); warn('未匹配到任务。'); return; }

  const trigger = args.trigger === 'ui' ? 'ui' : 'rpc';
  const metas = [];
  for (let i = 0; i < targets.length; i++) {
    const { id, name } = targets[i];
    try {
      const meta = await collectTask({ jobId: id, taskName: name, core, trigger, scenario: '自动化任务', variant });
      metas.push(meta);
    } catch (e) {
      warn(`任务 ${id} 采集异常：${e.message}`);
    }
    if (i < targets.length - 1) { log(`  冷却 ${CONFIG.cooldownMs}ms ...`); await sleep(CONFIG.cooldownMs); }
  }
  core.close();

  if (metas.length) {
    const out = await buildReport(CONFIG.sessionsDir);
    if (out) log(`可用浏览器打开报表：${out}`);
  }
}

async function cmdReport(args) {
  const dir = args._[1] ? path.resolve(args._[1]) : CONFIG.sessionsDir;
  const out = await buildReport(dir);
  if (out) log(`可用浏览器打开报表：${out}`);
}

function printHelp() {
  console.log(`nami-perfdog —— 纳米 Work 客户端性能验证工具

前置（测纳米且要 FPS/renderer 指标时）：先彻底退出纳米 Work（含托盘），再带调试端口启动：
  & "D:\\Program Files\\Namiwork\\Namiwork.exe" --remote-debugging-port=9222

用法：
  node nami-perfdog.mjs list-tasks
  node nami-perfdog.mjs run --manual [名称] [--variant <对象>]          手动框窗口：对话/切换对话
  node nami-perfdog.mjs run --scenario 对话|切换对话 [--variant <对象>]  同上（显式场景名）
  node nami-perfdog.mjs run --scenario 冷启动 [--variant <对象>]         先起工具再手动启动应用，测到"可用"(关键元素就绪)
  node nami-perfdog.mjs run --scenario 首次安装 [--proc <安装器进程名>] [--variant <对象>] 手动框全新安装起止
  node nami-perfdog.mjs run --scenario 热启动 [--variant <对象>]         后台恢复到窗口激活计时
  node nami-perfdog.mjs run --scenario 杀进程 [--variant <对象>]         手动关闭，测关闭耗时+资源释放
  node nami-perfdog.mjs run --scenario 长监控 [--duration 12h] [--variant <对象>]  长时挂机监控，到点或 Ctrl-C 结束
  node nami-perfdog.mjs run --task <id> / --match <词> [--variant <对象>] cron 定时任务
  node nami-perfdog.mjs report [sessionsDir]                            汇总成 场景×对象 对比矩阵

对比：--variant 给被测对象打标签（如 v2.3 / v2.4 / 竞品X）；同场景不同 variant 多跑几次，report 自动横向对比。
竞品：--proc <竞品进程名> 指定非纳米进程（如 Doubao.exe）；竞品无 CDP/nmcore 时只采系统级公共子集。
就绪：冷启动默认等输入框出现算"可用"；--ready-selector <css> 或 READY_SELECTOR 覆盖（落非对话视图可用 [class*="sidebar"]）。
环境变量：CDP_URL / CORE_WS / PING_HOST / SAMPLE_MS 等（见文件头 CONFIG）。`);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const cmd = args._[0];
  try {
    if (cmd === 'list-tasks') await cmdListTasks();
    else if (cmd === 'run') await cmdRun(args);
    else if (cmd === 'report') await cmdReport(args);
    else printHelp();
  } catch (e) {
    console.error('[perfdog][fatal]', e.message);
    process.exitCode = 1;
  }
}

// 仅作为主入口运行时执行；被 import（单测/验证）时只暴露纯函数、不跑 main。
import { pathToFileURL } from 'node:url';
const isMain = import.meta.url === pathToFileURL(process.argv[1] || '').href;
if (isMain) main();

export {
  stats, buildMeta, writeSession, buildReport, renderReportHtml,
  createStateMachine, loadSessions, CoreClient, CdpSession, tcpPing, CONFIG,
  collectTask, collectManual, newSessionCtx, startCollectors,
  makeSystemCollector, makeCdpCollector,
  collectKill, collectColdStart, collectWarmStart,
  waitProcAppear, waitProcGone, waitCdpReady, waitFirstPage, waitWindowActive, waitReadyElement, queryPids,
  makeForegroundProbe, waitForegroundActive,
  parseDuration, lttb, decimateSessionSamples,
  sessionDirFor, newStreamingSessionCtx, readSamplesFromDisk, fmtDur, heartbeatLine, memTrend,
  collectMonitor, recoverMeta,
};


